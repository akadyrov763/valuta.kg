import React, { useState } from "react";
import { 
  Percent, 
  ExternalLink, 
  Play, 
  PiggyBank, 
  FileSpreadsheet, 
  Sparkles, 
  HelpCircle,
  TrendingUp,
  ChevronRight
} from "lucide-react";
import { motion } from "motion/react";

interface DepositProduct {
  id: string;
  name: string;
  rate: number;
  term: number; // in months
  termDescription: string;
  currency: "KGS" | "USD";
  description: string;
  minAmount: string;
  benefits: string[];
}

interface MbankDepositsCardProps {
  onSelectProduct: (product: {
    name: string;
    rate: number;
    term: number;
    currency: "KGS" | "USD";
  }) => void;
  onLinkClick: (e: React.MouseEvent, url: string, bankName: string) => void;
  isDarkMode?: boolean;
}

const MBANK_PRODUCTS: DepositProduct[] = [
  {
    id: "mbank_nakop",
    name: "Накопительный KGS",
    rate: 12.0,
    term: 12,
    termDescription: "от 3 до 36 мес.",
    currency: "KGS",
    description: "Гибкий накопительный счет с высокой процентной ставкой, возможностью ежемесячного пополнения счета без ограничений.",
    minAmount: "1 000 сом",
    benefits: ["Ежемесячная капитализация процентов", "Пополнение в любое время через приложение"]
  },
  {
    id: "mbank_karavan",
    name: "Срочный Караван",
    rate: 13.0,
    term: 18,
    termDescription: "от 6 до 18 мес.",
    currency: "KGS",
    description: "Стабильный сберегательный депозит для получения максимального гарантированного дохода. Без возможности частичного изъятия.",
    minAmount: "5 000 сом",
    benefits: ["Высокая фиксированная ставка 13.0%", "Выплата начисленных процентов в конце срока"]
  },
  {
    id: "mbank_kopilka",
    name: "Копилка в MBANK",
    rate: 11.5,
    term: 6,
    termDescription: "Бессрочно",
    currency: "KGS",
    description: "Удобный инструмент в мобильном приложении MBANK. Накапливайте деньги незаметно с автоокруглением покупок или регулярным переводом.",
    minAmount: "Без минимума",
    benefits: ["Ежедневный подсчет потенциального дохода", "Свободное снятие без потери процентов в любое время"]
  },
  {
    id: "mbank_vygodny_usd",
    name: "Выгодный USD",
    rate: 4.0,
    term: 24,
    termDescription: "от 12 до 24 мес.",
    currency: "USD",
    description: "Надежное и выгодное хранение накоплений в иностранной валюте для диверсификации финансовых рисков.",
    minAmount: "$100 USD",
    benefits: ["Капитализация процентов", "Защита сбережений от валютных колебаний"]
  }
];

export default function MbankDepositsCard({ onSelectProduct, onLinkClick, isDarkMode = false }: MbankDepositsCardProps) {
  const [viewType, setViewType] = useState<"interactive" | "pandas">("interactive");
  const [hoveredRow, setHoveredRow] = useState<string | null>(null);

  const mbankDepositUrl = "https://mbank.kg/deposits";

  return (
    <div 
      className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-[28px] overflow-hidden shadow-sm"
      id="mbank-deposits-pro-card"
    >
      {/* Top Emerald/Green Brand Banner */}
      <div className="bg-gradient-to-r from-emerald-600 to-green-500 p-5 text-white flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="bg-white/10 backdrop-blur-md p-2.5 rounded-2xl border border-white/20 shadow-inner">
            <PiggyBank className="w-5 h-5 text-white animate-bounce-slow" />
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="text-[10px] font-mono font-bold tracking-widest bg-white/20 text-white px-2 py-0.5 rounded-md uppercase">
                MBANK PRO
              </span>
              <span className="w-2 h-2 rounded-full bg-emerald-300 animate-pulse" />
            </div>
            <h3 className="text-base font-extrabold tracking-tight mt-0.5">
              Депозитные Продукты MBANK
            </h3>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setViewType("interactive")}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1 cursor-pointer ${
              viewType === "interactive"
                ? "bg-white text-emerald-700 shadow-md scale-105"
                : "bg-emerald-700/40 text-emerald-100 hover:bg-emerald-700/60"
            }`}
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>Интерфейс</span>
          </button>
          
          <button
            onClick={() => setViewType("pandas")}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1 cursor-pointer ${
              viewType === "pandas"
                ? "bg-white text-emerald-700 shadow-md scale-105"
                : "bg-emerald-700/40 text-emerald-100 hover:bg-emerald-700/60"
            }`}
          >
            <FileSpreadsheet className="w-3.5 h-3.5" />
            <span>Pandas DataFrame</span>
          </button>
        </div>
      </div>

      <div className="p-6">
        {viewType === "interactive" ? (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-700 dark:text-slate-350 flex items-center gap-1.5">
                <TrendingUp className="w-4 h-4 text-emerald-500" />
                Линейка вкладов Банка Кыргызстан (MBANK)
              </span>
              <a
                href={mbankDepositUrl}
                target="_blank"
                rel="noopener noreferrer"
                onClick={(e) => onLinkClick(e, mbankDepositUrl, "МБАНК (Депозиты)")}
                className="text-xs font-bold text-emerald-600 dark:text-emerald-400 hover:text-emerald-700 dark:hover:text-emerald-300 flex items-center gap-1 cursor-pointer hover:underline"
              >
                <span>На сайт mbank.kg</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </a>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {MBANK_PRODUCTS.map((prod) => (
                <div 
                  key={prod.id}
                  className="bg-slate-50 dark:bg-slate-950 p-4 rounded-2xl border border-slate-200/80 dark:border-slate-800 flex flex-col justify-between hover:border-emerald-500/50 hover:shadow-xs transition-all group"
                >
                  <div>
                    <div className="flex justify-between items-start gap-2">
                      <div className="font-bold text-xs text-slate-900 dark:text-white group-hover:text-emerald-600 dark:group-hover:text-emerald-400 transition-colors">
                        {prod.name}
                      </div>
                      <div className="bg-emerald-100 dark:bg-emerald-950/50 text-emerald-700 dark:text-emerald-400 font-extrabold font-mono text-[11px] px-2 py-0.5 rounded-lg border border-emerald-200/50 dark:border-emerald-900/60 shrink-0">
                        {prod.rate.toFixed(1)}% {prod.currency === "USD" ? "USD" : "KGS"}
                      </div>
                    </div>
                    
                    <p className="text-[10px] text-slate-500 dark:text-slate-400 mt-2 leading-relaxed line-clamp-2">
                      {prod.description}
                    </p>

                    <div className="mt-3 pt-3 border-t border-slate-100 dark:border-slate-800 space-y-1.5 text-[10px] text-slate-550 dark:text-slate-400">
                      <div className="flex justify-between">
                        <span className="font-medium">Срок вклада:</span>
                        <span className="font-bold text-slate-800 dark:text-slate-200">{prod.termDescription}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="font-medium">Мин. сумма:</span>
                        <span className="font-bold text-slate-800 dark:text-slate-200">{prod.minAmount}</span>
                      </div>
                    </div>
                  </div>

                  <div className="mt-4 pt-3 border-t border-slate-150 dark:border-slate-800 flex items-center gap-2">
                    <button
                      onClick={() => onSelectProduct({
                        name: prod.name,
                        rate: prod.rate,
                        term: prod.term,
                        currency: prod.currency
                      })}
                      className="flex-1 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white text-[10px] font-bold rounded-lg text-center transition-all flex items-center justify-center gap-1 cursor-pointer shadow-3xs"
                    >
                      <Play className="w-3 h-3 fill-white" />
                      <span>Рассчитать доход</span>
                    </button>
                    
                    <a
                      href={mbankDepositUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      onClick={(e) => onLinkClick(e, mbankDepositUrl, "МБАНК (" + prod.name + ")")}
                      className="px-2.5 py-1.5 bg-slate-200/80 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-350 hover:text-slate-900 dark:hover:text-white border border-transparent text-[10px] font-bold rounded-lg transition-all flex items-center justify-center cursor-pointer"
                      title="Официальная страница"
                    >
                      <ExternalLink className="w-3.5 h-3.5" />
                    </a>
                  </div>
                </div>
              ))}
            </div>
          </div>
        ) : (
          <div className="space-y-4 font-mono">
            {/* Python Style Console Header */}
            <div className="bg-slate-100 dark:bg-slate-950 p-2.5 rounded-lg border border-slate-200 dark:border-slate-800 text-[10px] text-slate-500 dark:text-slate-400 flex items-center justify-between">
              <span className="font-mono font-bold tracking-normal text-emerald-600">In [24]: df_deposits_only.style.set_properties()</span>
              <span className="text-[9px] bg-slate-200 dark:bg-slate-800 px-1.5 py-0.5 rounded font-bold uppercase tracking-wider text-slate-500">pandas</span>
            </div>

            <div className="text-xs text-slate-600 dark:text-slate-350 py-1 border-l-2 border-emerald-500 pl-3">
              --- ДЕПОЗИТНЫЕ ПРОДУКТЫ MBANK ---
            </div>

            {/* Pandas styled table replicating user's exact styling code results */}
            <div className="overflow-x-auto border border-slate-200 dark:border-slate-800 rounded-lg">
              <table className="w-full text-left font-mono text-[11px] border-collapse" style={{ borderColor: isDarkMode ? "#1e293b" : "white" }}>
                <thead>
                  <tr>
                    <th 
                      className={`p-3 border-b-2 ${isDarkMode ? "border-slate-800" : "border-white"} text-center font-bold font-mono`} 
                      style={{ backgroundColor: isDarkMode ? "#1b431e" : "#4CAF50", color: "white" }}
                    >
                      #
                    </th>
                    <th 
                      className={`p-3 border-b-2 ${isDarkMode ? "border-slate-800" : "border-white"} text-left font-bold font-mono`} 
                      style={{ backgroundColor: isDarkMode ? "#1b431e" : "#4CAF50", color: "white" }}
                    >
                      Название
                    </th>
                    <th 
                      className={`p-3 border-b-2 ${isDarkMode ? "border-slate-800" : "border-white"} text-right font-bold font-mono`} 
                      style={{ backgroundColor: isDarkMode ? "#1b431e" : "#4CAF50", color: "white" }}
                    >
                      Ставка
                    </th>
                    <th 
                      className={`p-3 border-b-2 ${isDarkMode ? "border-slate-800" : "border-white"} text-right font-bold font-mono`} 
                      style={{ backgroundColor: isDarkMode ? "#1b431e" : "#4CAF50", color: "white" }}
                    >
                      Срок
                    </th>
                    <th 
                      className={`p-3 border-b-2 ${isDarkMode ? "border-slate-800" : "border-white"} text-center font-bold font-mono`} 
                      style={{ backgroundColor: isDarkMode ? "#1b431e" : "#4CAF50", color: "white" }}
                    >
                      Действие
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {MBANK_PRODUCTS.map((prod, index) => (
                    <tr 
                      key={prod.id} 
                      onMouseEnter={() => setHoveredRow(prod.id)}
                      onMouseLeave={() => setHoveredRow(null)}
                      className={`border-b ${isDarkMode ? "border-slate-800" : "border-white"} transition-colors`}
                      style={{ 
                        backgroundColor: isDarkMode 
                          ? (hoveredRow === prod.id ? "#131f37" : "#020617") 
                          : (hoveredRow === prod.id ? "#eff6ff" : "#f9f9f9"),
                        color: isDarkMode ? "#f1f5f9" : "#1e293b"
                      }}
                    >
                      <td className={`p-3 font-semibold text-center ${isDarkMode ? "border-r border-slate-800" : "border-r border-white"} font-mono text-slate-500 dark:text-slate-400`}>{index}</td>
                      <td className={`p-3 font-bold ${isDarkMode ? "border-r border-slate-800" : "border-r border-white"} font-mono`}>{prod.name}</td>
                      <td className={`p-3 text-right font-black ${isDarkMode ? "border-r border-slate-800" : "border-r border-white"} ${isDarkMode ? "text-emerald-400" : "text-emerald-700"} font-mono`}>
                        {prod.rate.toFixed(1)}% {prod.currency === "USD" ? "USD" : "KGS"}
                      </td>
                      <td className={`p-3 text-right font-bold ${isDarkMode ? "border-r border-slate-800" : "border-r border-white"} ${isDarkMode ? "text-slate-450" : "text-slate-600"} font-mono`}>
                        {prod.termDescription}
                      </td>
                      <td className="p-2 text-center">
                        <button
                          onClick={() => onSelectProduct({
                            name: prod.name,
                            rate: prod.rate,
                            term: prod.term,
                            currency: prod.currency
                          })}
                          className="px-2 py-1 bg-emerald-600 hover:bg-emerald-700 text-white rounded font-bold font-mono text-[9px] uppercase tracking-wider cursor-pointer"
                        >
                          RUN ⚙️
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <div className="text-[10px] text-slate-500 flex items-center gap-1 font-mono pt-1">
              <span className="text-amber-500">💡 Tip:</span>
              <span>Нажмите кнопку <strong className="text-emerald-600">RUN ⚙️</strong> в строке, чтобы загрузить параметры депозита напрямую в калькулятор ниже.</span>
            </div>
          </div>
        )}
      </div>

      {/* Info bar at bottom */}
      <div className="bg-slate-50 dark:bg-slate-950 px-6 py-3.5 border-t border-slate-150 dark:border-slate-800 text-[10px] text-slate-500 dark:text-slate-400 flex items-center justify-between">
        <span className="font-semibold flex items-center gap-1.5 font-sans">
          <HelpCircle className="w-3.5 h-3.5 text-blue-500" />
          Все вклады застрахованы Агентством по защите депозитов КР в размере до 1 млн сомов.
        </span>
        <a
          href={mbankDepositUrl}
          target="_blank"
          rel="noopener noreferrer"
          onClick={(e) => onLinkClick(e, mbankDepositUrl, "МБАНК (Депозиты)")}
          className="text-emerald-700 dark:text-emerald-400 font-bold hover:underline hidden sm:flex items-center gap-1 font-sans cursor-pointer"
        >
          <span>Оформить онлайн</span>
          <ChevronRight className="w-3 h-3" />
        </a>
      </div>
    </div>
  );
}
