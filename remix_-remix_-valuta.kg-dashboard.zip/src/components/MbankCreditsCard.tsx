import React, { useState } from "react";
import { 
  Percent, 
  ExternalLink, 
  Play, 
  CircleDollarSign, 
  FileSpreadsheet, 
  Sparkles, 
  HelpCircle,
  TrendingUp,
  ChevronRight,
  Home,
  Smartphone,
  Car,
  Briefcase
} from "lucide-react";

interface CreditProduct {
  id: string;
  type: string;
  name: string;
  rate: number;
  rateStr: string;
  term: number; // in months
  termStr: string;
  features: string;
  description: string;
  icon: React.ReactNode;
  suggestedAmount: number;
  url?: string;
}

interface MbankCreditsCardProps {
  onSelectProduct: (product: {
    name: string;
    rate: number;
    term: number;
    suggestedAmount: number;
  }) => void;
  onLinkClick: (e: React.MouseEvent, url: string, bankName: string) => void;
  isDarkMode?: boolean;
}

export default function MbankCreditsCard({ onSelectProduct, onLinkClick, isDarkMode = false }: MbankCreditsCardProps) {
  const [viewType, setViewType] = useState<"interactive" | "pandas">("interactive");
  const [hoveredRow, setHoveredRow] = useState<string | null>(null);

  const mbankCreditUrl = "https://mbank.kg/credits";

  const MBANK_CREDITS: CreditProduct[] = [
    {
      id: "mbank_mortgage",
      type: "Ипотека",
      name: "Мой дом",
      rate: 22.0,
      rateStr: "от 22%",
      term: 120,
      termStr: "до 120 мес",
      features: "Собственное жилье",
      description: "Ипотечный кредит на приобретение готового или строящегося жилья с минимальным пакетом документов.",
      suggestedAmount: 3000000,
      icon: <Home className="w-4 h-4 text-rose-500" />,
      url: "https://mbank.kg/credits"
    },
    {
      id: "mbank_online",
      type: "Онлайн-кредит",
      name: "Кредит в приложении",
      rate: 28.0,
      rateStr: "от 28%",
      term: 36,
      termStr: "до 36 мес",
      features: "Без визита в банк",
      description: "Получение кредита за пару минут прямо в приложении MBANK без поручителей и бумажных справок.",
      suggestedAmount: 150000,
      icon: <Smartphone className="w-4 h-4 text-emerald-500" />,
      url: "https://mbank.kg/credits"
    },
    {
      id: "mbank_auto",
      type: "Автокредит",
      name: "Авто-финансирование",
      rate: 24.0,
      rateStr: "от 24%",
      term: 60,
      termStr: "до 60 мес",
      features: "На новые и б/у авто",
      description: "Кредит на покупку автотранспорта. Быстрое рассмотрение и гибкие условия погашения.",
      suggestedAmount: 800000,
      icon: <Car className="w-4 h-4 text-blue-500" />
    },
    {
      id: "mbank_business",
      type: "Бизнес",
      name: "Бизнес-рост",
      rate: 18.0,
      rateStr: "от 18%",
      term: 48,
      termStr: "до 48 мес",
      features: "Для ИП и юрлиц",
      description: "Финансирование оборотного капитала и инвестиций в развитие малого и среднего бизнеса.",
      suggestedAmount: 1000000,
      icon: <Briefcase className="w-4 h-4 text-amber-500" />
    }
  ];

  return (
    <div 
      className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-[28px] overflow-hidden shadow-sm"
      id="mbank-credits-pro-card"
    >
      {/* Top Red/Rose Brand Banner reflecting MBANK's expanded credits scheme */}
      <div className="bg-gradient-to-r from-red-700 to-rose-600 p-5 text-white flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="bg-white/10 backdrop-blur-md p-2.5 rounded-2xl border border-white/20 shadow-inner">
            <CircleDollarSign className="w-5 h-5 text-white" />
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="text-[10px] font-mono font-bold tracking-widest bg-white/20 text-white px-2 py-0.5 rounded-md uppercase">
                MBANK LOANS
              </span>
              <span className="w-2 h-2 rounded-full bg-red-300 animate-pulse" />
            </div>
            <h3 className="text-base font-extrabold tracking-tight mt-0.5">
              Кредитные Продукты MBANK
            </h3>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setViewType("interactive")}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1 cursor-pointer ${
              viewType === "interactive"
                ? "bg-white text-red-700 shadow-md scale-105"
                : "bg-red-800/40 text-red-100 hover:bg-red-850/60"
            }`}
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>Интерфейс</span>
          </button>
          
          <button
            onClick={() => setViewType("pandas")}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1 cursor-pointer ${
              viewType === "pandas"
                ? "bg-white text-red-700 shadow-md scale-105"
                : "bg-red-800/40 text-red-100 hover:bg-red-850/60"
            }`}
          >
            <FileSpreadsheet className="w-3.5 h-3.5" />
            <span>Pandas DataFrame</span>
          </button>
        </div>
      </div>

      <div className="p-6">
        {viewType === "interactive" ? (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-700 dark:text-slate-350 flex items-center gap-1.5">
                <TrendingUp className="w-4 h-4 text-red-500" />
                Линейка кредитования Банка Кыргызстан (MBANK)
              </span>
              <a
                href={mbankCreditUrl}
                target="_blank"
                rel="noopener noreferrer"
                onClick={(e) => onLinkClick(e, mbankCreditUrl, "МБАНК (Кредиты)")}
                className="text-xs font-bold text-red-600 dark:text-red-400 hover:text-red-700 dark:hover:text-red-300 flex items-center gap-1 cursor-pointer hover:underline"
              >
                    <span>Оформить кредит на mbank.kg</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </a>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {MBANK_CREDITS.map((prod) => (
                <div 
                  key={prod.id}
                  className="bg-slate-50 dark:bg-slate-950 p-4 rounded-2xl border border-slate-200/80 dark:border-slate-800 flex flex-col justify-between hover:border-red-500/50 hover:shadow-xs transition-all group"
                >
                  <div>
                    <div className="flex justify-between items-start gap-2">
                      <div className="flex items-center gap-2">
                        <div className="bg-white dark:bg-slate-900 p-2 rounded-xl border border-slate-150 dark:border-slate-800 shadow-3xs group-hover:scale-105 transition-transform">
                          {prod.icon}
                        </div>
                        <div>
                          <span className="text-[9px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider">{prod.type}</span>
                          <div className="font-extrabold text-xs text-slate-900 dark:text-white group-hover:text-red-600 dark:group-hover:text-red-400 transition-colors">
                            {prod.name}
                          </div>
                        </div>
                      </div>
                      
                      <div className="bg-red-50 dark:bg-red-950/40 text-red-650 dark:text-red-400 font-black font-mono text-[11px] px-2 py-1 rounded-lg border border-red-200/40 dark:border-red-900/40 shrink-0">
                        {prod.rateStr}
                      </div>
                    </div>
                    
                    <p className="text-[10px] text-slate-500 dark:text-slate-400 mt-2.5 leading-relaxed">
                      {prod.description}
                    </p>

                    <div className="mt-3.5 pt-3 border-t border-slate-150 dark:border-slate-800 space-y-1.5 text-[10px] text-slate-550 dark:text-slate-400">
                      <div className="flex justify-between">
                        <span className="font-medium">Срок финансирования:</span>
                        <span className="font-bold text-slate-800 dark:text-slate-200">{prod.termStr}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="font-medium">Особенности корта:</span>
                        <span className="font-bold text-red-600 dark:text-red-400 bg-red-50 dark:bg-red-950/30 px-1.5 py-0.5 rounded-md">{prod.features}</span>
                      </div>
                    </div>
                  </div>

                  <div className="mt-4 pt-3 border-t border-slate-150 dark:border-slate-800 flex items-center gap-2">
                    <button
                      onClick={() => onSelectProduct({
                        name: prod.name,
                        rate: prod.rate,
                        term: prod.term,
                        suggestedAmount: prod.suggestedAmount
                      })}
                      className="flex-1 py-1.5 bg-red-600 hover:bg-red-700 text-white text-[10px] font-bold rounded-lg text-center transition-all flex items-center justify-center gap-1 cursor-pointer shadow-3xs"
                    >
                      <Play className="w-3 h-3 fill-white" />
                      <span>Параметры в калькулятор</span>
                    </button>
                    
                    <a
                      href={prod.url || mbankCreditUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      onClick={(e) => onLinkClick(e, prod.url || mbankCreditUrl, "МБАНК (" + prod.name + ")")}
                      className="px-2.5 py-1.5 bg-slate-200/80 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-350 hover:text-slate-900 dark:hover:text-white border border-transparent text-[10px] font-bold rounded-lg transition-all flex items-center justify-center cursor-pointer"
                      title="Официальная страница"
                    >
                      <ExternalLink className="w-3.5 h-3.5" />
                    </a>
                  </div>
                </div>
              ))}
            </div>
          </div>
        ) : (
          <div className="space-y-4 font-mono">
            {/* Python-like console code snippet */}
            <div className="bg-slate-100 dark:bg-slate-940 p-2.5 rounded-xl border border-slate-250/70 dark:border-slate-800 text-[10px] text-slate-550 dark:text-slate-400 flex items-center justify-between">
              <span className="font-mono font-bold tracking-normal text-red-600">In [42]: display(df_credits_detailed.style.set_properties(...))</span>
              <span className="text-[9px] bg-slate-200 dark:bg-slate-800 px-1.5 py-0.5 rounded font-bold uppercase tracking-wider text-slate-500">pandas</span>
            </div>

            {/* Simulated styled pandas frame with custom border and bg matching user request */}
            <div className={`p-1.5 ${isDarkMode ? "bg-slate-950 border-red-950" : "bg-white border-red-200"} border rounded-xl overflow-x-auto`}>
              <div className="text-[11px] font-bold text-slate-700 dark:text-slate-305 px-1 pb-1 text-left font-sans italic">
                Детальные условия по кредитам MBANK
              </div>
              <table className="w-full text-left font-mono text-[11px] border-collapse" style={{ border: isDarkMode ? "1px solid #7f1d1d" : "1px solid #ffcdd2" }}>
                <thead>
                  <tr style={{ borderBottom: isDarkMode ? "1px solid #7f1d1d" : "1px solid #ffcdd2" }}>
                    <th 
                      className="p-3 font-mono text-center font-bold" 
                      style={{ backgroundColor: isDarkMode ? "#7f1d1d" : "#d32f2f", color: "white", fontSize: "12px" }}
                    >
                      #
                    </th>
                    <th 
                      className="p-3 font-mono text-left font-bold" 
                      style={{ backgroundColor: isDarkMode ? "#7f1d1d" : "#d32f2f", color: "white", fontSize: "12px" }}
                    >
                      Тип
                    </th>
                    <th 
                      className="p-3 font-mono text-left font-bold" 
                      style={{ backgroundColor: isDarkMode ? "#7f1d1d" : "#d32f2f", color: "white", fontSize: "12px" }}
                    >
                      Название
                    </th>
                    <th 
                      className="p-3 font-mono text-right font-bold" 
                      style={{ backgroundColor: isDarkMode ? "#7f1d1d" : "#d32f2f", color: "white", fontSize: "12px" }}
                    >
                      Ставка
                    </th>
                    <th 
                      className="p-3 font-mono text-right font-bold" 
                      style={{ backgroundColor: isDarkMode ? "#7f1d1d" : "#d32f2f", color: "white", fontSize: "12px" }}
                    >
                      Срок
                    </th>
                    <th 
                      className="p-3 font-mono text-left font-bold" 
                      style={{ backgroundColor: isDarkMode ? "#7f1d1d" : "#d32f2f", color: "white", fontSize: "12px" }}
                    >
                      Особенности
                    </th>
                    <th 
                      className="p-2 font-mono text-center font-bold" 
                      style={{ backgroundColor: isDarkMode ? "#7f1d1d" : "#d32f2f", color: "white", fontSize: "11px" }}
                    >
                      Действие
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {MBANK_CREDITS.map((prod, index) => (
                    <tr 
                      key={prod.id} 
                      onMouseEnter={() => setHoveredRow(prod.id)}
                      onMouseLeave={() => setHoveredRow(null)}
                      className={`border-b ${isDarkMode ? "border-red-950/40" : "border-red-100"} transition-colors`}
                      style={{ 
                        backgroundColor: isDarkMode 
                          ? (hoveredRow === prod.id ? "#291313" : "#020617") 
                          : (hoveredRow === prod.id ? "#ffebee" : "#fffafa"),
                        borderColor: isDarkMode ? "#581c1c" : "#ffcdd2",
                        color: isDarkMode ? "#e2e8f0" : "#1e293b"
                      }}
                    >
                      <td className="p-3 font-bold text-center border-r" style={{ borderColor: isDarkMode ? "#581c1c" : "#ffcdd2" }}>{index}</td>
                      <td className="p-3 font-medium border-r" style={{ borderColor: isDarkMode ? "#581c1c" : "#ffcdd2" }}>{prod.type}</td>
                      <td className={`p-3 font-black border-r ${isDarkMode ? "text-red-400" : "text-red-700"}`} style={{ borderColor: isDarkMode ? "#581c1c" : "#ffcdd2" }}>{prod.name}</td>
                      <td className={`p-3 text-right font-black border-r ${isDarkMode ? "text-emerald-400" : "text-emerald-750"}`} style={{ borderColor: isDarkMode ? "#581c1c" : "#ffcdd2" }}>{prod.rateStr}</td>
                      <td className="p-3 text-right font-bold border-r" style={{ borderColor: isDarkMode ? "#581c1c" : "#ffcdd2" }}>{prod.termStr}</td>
                      <td className="p-3 font-medium border-r" style={{ borderColor: isDarkMode ? "#581c1c" : "#ffcdd2" }}>{prod.features}</td>
                      <td className="p-2 text-center">
                        <button
                          onClick={() => onSelectProduct({
                            name: prod.name,
                            rate: prod.rate,
                            term: prod.term,
                            suggestedAmount: prod.suggestedAmount
                          })}
                          className="px-2.5 py-1 bg-red-600 hover:bg-red-700 text-white rounded font-bold font-mono text-[9px] uppercase tracking-wider cursor-pointer"
                        >
                          RUN ⚙️
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <div className="text-[10px] text-slate-500 flex items-center gap-1 font-mono pt-1">
              <span className="text-amber-500">💡 Tip:</span>
              <span>Клавиша <strong className="text-red-650">RUN ⚙️</strong> наполняет аннуитетный калькулятор официальными спецификациями кредита!</span>
            </div>
          </div>
        )}
      </div>

      {/* Info bar at bottom */}
      <div className="bg-slate-50 dark:bg-slate-950 px-6 py-3.5 border-t border-slate-150 dark:border-slate-800 text-[10px] text-slate-500 dark:text-slate-400 flex items-center justify-between">
        <span className="font-semibold flex items-center gap-1.5 font-sans">
          <HelpCircle className="w-3.5 h-3.5 text-blue-500" />
          Внимание: Конечная процентная ставка устанавливается кредитным комитетом индивидуально.
        </span>
        <a
          href={mbankCreditUrl}
          target="_blank"
          rel="noopener noreferrer"
          onClick={(e) => onLinkClick(e, mbankCreditUrl, "МБАНК (Кредиты)")}
          className="text-red-700 dark:text-red-400 font-bold hover:underline hidden sm:flex items-center gap-1 font-sans cursor-pointer"
        >
          <span>Подать заявку онлайн</span>
          <ChevronRight className="w-3 h-3" />
        </a>
      </div>
    </div>
  );
}
