import React, { useState, useEffect, useRef } from "react";
import {
  TrendingUp,
  TrendingDown,
  RefreshCcw,
  Calculator,
  Globe,
  Building2,
  Phone,
  MapPin,
  MessageSquare,
  Send,
  Sparkles,
  Info,
  DollarSign,
  Check,
  Star,
  ChevronRight,
  Scale,
  Percent,
  PiggyBank,
  CreditCard,
  ArrowRightLeft,
  X,
  Search,
  ExternalLink,
  Sun,
  Moon,
  Copy
} from "lucide-react";
import { BankRates, CurrencyHistoryPoint, Message } from "./types";
import { defaultBanksList, initialHistoryData, currencyDescriptions } from "./data";
import { motion, AnimatePresence } from "motion/react";
import MbankDepositsCard from "./components/MbankDepositsCard";
import MbankCreditsCard from "./components/MbankCreditsCard";


export default function App() {
  // Dark mode theme state with localStorage persistence
  const [isDarkMode, setIsDarkMode] = useState<boolean>(() => {
    if (typeof window !== "undefined" && window.localStorage) {
      const stored = window.localStorage.getItem("theme");
      if (stored) return stored === "dark";
      return false;
    }
    return false;
  });

  // Apply CSS class to document root element on state changes
  useEffect(() => {
    const root = window.document.documentElement;
    if (isDarkMode) {
      root.classList.add("dark");
      window.localStorage?.setItem("theme", "dark");
    } else {
      root.classList.remove("dark");
      window.localStorage?.setItem("theme", "light");
    }
  }, [isDarkMode]);

  // Toast notification state
  const [toast, setToast] = useState<{ message: string; visible: boolean } | null>(null);

  // Safe navigation fallback modal state
  const [safeLinkModal, setSafeLinkModal] = useState<{
    isOpen: boolean;
    url: string;
    bankName: string;
  }>({
    isOpen: false,
    url: "",
    bankName: ""
  });

  // Show a message toast
  const showToast = (message: string) => {
    setToast({ message, visible: true });
  };

  // Auto-dismiss toast after 4.5 seconds
  useEffect(() => {
    if (toast?.visible) {
      const timer = setTimeout(() => {
        setToast(prev => prev ? { ...prev, visible: false } : null);
      }, 4500);
      return () => clearTimeout(timer);
    }
  }, [toast?.visible]);

  // Safe navigation function: prevents default broken iframe navigation, copies link to clipboard, and shows user a helpful copy-redirect modal
  const handleSafeLinkClick = (e: React.MouseEvent, url: string, bankName: string) => {
    e.preventDefault();
    try {
      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(url);
      }
    } catch (err) {
      console.warn("Clipboard access failed:", err);
    }
    setSafeLinkModal({
      isOpen: true,
      url,
      bankName
    });
  };

  // Navigation tabs
  const [activeTab, setActiveTab] = useState<"rates" | "banks" | "loans" | "deposits">("rates");
  
  // Currency tabs for exchange rate & graph
  const [selectedCurrency, setSelectedCurrency] = useState<"USD" | "EUR" | "RUB" | "KZT">("USD");
  
  // Exchange Rates state
  const [rates, setRates] = useState<BankRates[]>([]);
  const [isLoadingRates, setIsLoadingRates] = useState<boolean>(false);
  const [ratesSource, setRatesSource] = useState<string>("Загрузка...");
  const [searchBankQuery, setSearchBankQuery] = useState<string>("");
  const [sortField, setSortField] = useState<"buy" | "sell" | "none">("none");
  const [sortOrder, setSortOrder] = useState<"asc" | "desc">("desc");

  // Real-time tick countdown (simulating real-time live data feed refresh)
  const [countdown, setCountdown] = useState<number>(15);

  // Currency Converter Calculator state
  const [calcAmount, setCalcAmount] = useState<string>("1000");
  const [calcFrom, setCalcFrom] = useState<string>("USD");
  const [calcTo, setCalcTo] = useState<string>("KGS");

  // Loans Calculator state
  const [loanPrincipal, setLoanPrincipal] = useState<number>(300000);
  const [loanTerm, setLoanTerm] = useState<number>(12);
  const [loanRate, setLoanRate] = useState<number>(15);
  const [loanCurrency, setLoanCurrency] = useState<"KGS" | "USD">("KGS");

  // Deposits Calculator state
  const [depPrincipal, setDepPrincipal] = useState<number>(100000);
  const [depTerm, setDepTerm] = useState<number>(12);
  const [depRate, setDepRate] = useState<number>(13);
  const [depCurrency, setDepCurrency] = useState<"KGS" | "USD">("KGS");

  // Graph state - historical rates point representing movement
  const [historyPoints, setHistoryPoints] = useState<CurrencyHistoryPoint[]>(initialHistoryData);

  // Chat/AI assistant state
  const [messages, setMessages] = useState<Message[]>([
    {
      sender: "assistant",
      text: "👋 Привет! Я твой ИИ-помощник по валютам и инвестициям в Кыргызстане. Я умею сканировать финансовый рынок КР и агрегировать новости в реальном времени с помощью Google Search.\n\nВы можете спросить меня:\n• Сводка финансовых новостей Кыргызстана, влияющих на курсы валют 📰\n• Где самый выгодный курс продажи долларов в Бишкеке?\n• В каком банке выгодно открыть депозит под высокий процент?\n• Какой банк предлагает лучшую ставку на кредит?",
      timestamp: new Date().toLocaleTimeString("ru-RU", { hour: "2-digit", minute: "2-digit" })
    }
  ]);
  const [userInput, setUserInput] = useState<string>("");
  const [isSendingToAI, setIsSendingToAI] = useState<boolean>(false);
  const chatBottomRef = useRef<HTMLDivElement | null>(null);

  // Selected bank details modal
  const [selectedBankIdForModal, setSelectedBankIdForModal] = useState<string | null>(null);

  // Comparison States
  const [compareBankIdA, setCompareBankIdA] = useState<string>("bakai");
  const [compareBankIdB, setCompareBankIdB] = useState<string>("optima");
  const [isCompareModalOpen, setIsCompareModalOpen] = useState<boolean>(false);

  // AI Course Forecast States
  const [showForecast, setShowForecast] = useState<boolean>(true);
  const [forecastMode, setForecastMode] = useState<"steady" | "growth" | "drop">("steady");
  const [hoveredPointData, setHoveredPointData] = useState<{ x: number; y: number; label: string; val: number; isForecast: boolean } | null>(null);

  // Favorite Banks State with localStorage persistence
  const [favoriteBankIds, setFavoriteBankIds] = useState<string[]>(() => {
    if (typeof window !== "undefined" && window.localStorage) {
      const stored = window.localStorage.getItem("favorite_banks");
      return stored ? JSON.parse(stored) : [];
    }
    return [];
  });

  // Persist favorites to localStorage
  useEffect(() => {
    if (typeof window !== "undefined" && window.localStorage) {
      window.localStorage.setItem("favorite_banks", JSON.stringify(favoriteBankIds));
    }
  }, [favoriteBankIds]);

  const toggleFavorite = (bankId: string) => {
    setFavoriteBankIds(prev =>
      prev.includes(bankId) ? prev.filter(id => id !== bankId) : [...prev, bankId]
    );
  };

  // Keyboard Hotkeys for fast navigation (Ctrl+1, Ctrl+2, Ctrl+3, Ctrl+4)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      const isModifier = e.ctrlKey || e.altKey || e.metaKey;
      if (!isModifier) return;

      const key = e.key;
      if (key === "1") {
        e.preventDefault();
        setActiveTab("rates");
      } else if (key === "2") {
        e.preventDefault();
        setActiveTab("banks");
      } else if (key === "3") {
        e.preventDefault();
        setActiveTab("loans");
      } else if (key === "4") {
        e.preventDefault();
        setActiveTab("deposits");
      }
    };

    window.addEventListener("keydown", handleKeyDown);
    return () => {
      window.removeEventListener("keydown", handleKeyDown);
    };
  }, []);

  // Fetch Exchange rates from server API
  const fetchRates = async (liveSource: boolean = false) => {
    setIsLoadingRates(true);
    if (liveSource) {
      setRatesSource("ИИ сканирует valuta.kg в реальном времени...");
    }
    try {
      const response = await fetch(`/api/rates${liveSource ? "?live=true" : ""}`);
      const data = await response.json();
      if (data.success && data.rates) {
        setRates(data.rates);
        setRatesSource(data.note || "Обновлено в реальном времени");
        setCountdown(15);
        
        // Slightly fluctuate historic graph points on fresh fetch to signify life/live ticks!
        setHistoryPoints(prev => {
          return prev.map((point, index) => {
            if (index === prev.length - 1) {
              // Current point is updated to match the market average
              const sum = data.rates.reduce((acc: number, item: any) => acc + item.rates[selectedCurrency].buy, 0);
              const avg = parseFloat((sum / data.rates.length).toFixed(selectedCurrency === 'RUB' || selectedCurrency === 'KZT' ? 3 : 2));
              return { ...point, [selectedCurrency]: avg };
            }
            // Other historical points slightly fluctuate
            const change = (Math.random() - 0.5) * (selectedCurrency === 'RUB' || selectedCurrency === 'KZT' ? 0.005 : 0.04);
            return {
              ...point,
              [selectedCurrency]: parseFloat((point[selectedCurrency] + change).toFixed(selectedCurrency === 'RUB' || selectedCurrency === 'KZT' ? 3 : 2))
            };
          });
        });

      } else {
        setRatesSource("Превышен лимит запросов, запущен резервный кэш");
      }
    } catch (e) {
      console.log("Failed fetching rates info:", String(e));
      setRatesSource("Ошибка подключения. Активен резервный автономный режим");
    } finally {
      setIsLoadingRates(false);
    }
  };

  // Initial load
  useEffect(() => {
    fetchRates(false);
  }, []);

  // Interval automated simulator checks
  useEffect(() => {
    const timer = setInterval(() => {
      setCountdown(prev => {
        if (prev <= 1) {
          fetchRates(false); // background fetch refresh
          return 15;
        }
        return prev - 1;
      });
    }, 1000);
    return () => clearInterval(timer);
  }, [selectedCurrency]);

  // Handle graph and search/sorting operations
  const handleBankSort = (field: "buy" | "sell") => {
    if (sortField === field) {
      setSortOrder(prev => (prev === "asc" ? "desc" : "asc"));
    } else {
      setSortField(field);
      setSortOrder("desc");
    }
  };

  // Filtered and Sorted list with favorite banks pinned at the top
  const filteredRatesAndBanks = rates
    .filter(item => {
      const matchSearch =
        item.bankNameRu.toLowerCase().includes(searchBankQuery.toLowerCase()) ||
        item.bankName.toLowerCase().includes(searchBankQuery.toLowerCase());
      return matchSearch;
    })
    .sort((a, b) => {
      const isFavA = favoriteBankIds.includes(a.bankId);
      const isFavB = favoriteBankIds.includes(b.bankId);

      // Pin favorites to the top
      if (isFavA && !isFavB) return -1;
      if (!isFavA && isFavB) return 1;

      // Within their respective status (both favorite or both normal), sort by field
      if (sortField === "none") return 0;
      const valA = a.rates[selectedCurrency][sortField];
      const valB = b.rates[selectedCurrency][sortField];
      return sortOrder === "desc" ? valB - valA : valA - valB;
    });

  // Highlight maximum buy and minimum sell rates to spot the best opportunities!
  const getExtremeRates = () => {
    if (rates.length === 0) return { maxBuy: 0, minSell: Number.MAX_VALUE };
    const buyRates = rates.map(r => r.rates[selectedCurrency].buy);
    const sellRates = rates.map(r => r.rates[selectedCurrency].sell);
    return {
      maxBuy: Math.max(...buyRates),
      minSell: Math.min(...sellRates)
    };
  };

  const { maxBuy, minSell } = getExtremeRates();

  // Convert calculation
  const getConvertedOutput = () => {
    const amountNum = parseFloat(calcAmount) || 0;
    if (amountNum <= 0) return "0.00";

    // Use Bakai Bank average rates or fallback rate context
    const refBank = rates.find(r => r.bankId === "bakai") || rates[0];
    if (!refBank) return "0.00";

    if (calcFrom === "KGS") {
      const rate = refBank.rates[calcTo as "USD" | "EUR" | "RUB" | "KZT"]?.sell || 1;
      return (amountNum / rate).toFixed(calcTo === "RUB" || calcTo === "KZT" ? 2 : 2);
    } else if (calcTo === "KGS") {
      const rate = refBank.rates[calcFrom as "USD" | "EUR" | "RUB" | "KZT"]?.buy || 1;
      return (amountNum * rate).toFixed(2);
    } else {
      // Cross rate over KGS
      const rateFromKgs = refBank.rates[calcFrom as "USD" | "EUR" | "RUB" | "KZT"]?.buy || 1;
      const rateToKgs = refBank.rates[calcTo as "USD" | "EUR" | "RUB" | "KZT"]?.sell || 1;
      return ((amountNum * rateFromKgs) / rateToKgs).toFixed(2);
    }
  };

  // Loan calculator outputs (annuity formula)
  const calculateLoan = () => {
    const monthlyRate = (loanRate / 100) / 12;
    const termMonths = loanTerm;
    
    if (monthlyRate === 0) {
      const monthly = loanPrincipal / termMonths;
      return {
        monthlyPayment: monthly,
        totalPaid: loanPrincipal,
        totalInterest: 0
      };
    }

    const monthlyPayment = loanPrincipal * (monthlyRate * Math.pow(1 + monthlyRate, termMonths)) / (Math.pow(1 + monthlyRate, termMonths) - 1);
    const totalPaid = monthlyPayment * termMonths;
    const totalInterest = totalPaid - loanPrincipal;

    return {
      monthlyPayment,
      totalPaid,
      totalInterest
    };
  };

  const loanResults = calculateLoan();

  // Deposit calculator output
  const calculateDeposit = () => {
    const yearRate = depRate / 100;
    const months = depTerm;
    // Simple deposit interest calculation
    const earnedInterest = depPrincipal * yearRate * (months / 12);
    // Tax under Kyrgyz law - 10% index fee on specific non-residents or new initiatives, standard local banks can have minor taxes. Let's assume net som yield.
    const taxValue = earnedInterest * 0.05; // 5% simulated regional tax or none
    const netPayout = depPrincipal + earnedInterest - taxValue;

    return {
      earnedInterest,
      taxValue,
      netPayout
    };
  };

  const depositResults = calculateDeposit();

  // Selected Bank Object for details
  const currentSelectedBankObj = defaultBanksList.find(b => b.id === selectedBankIdForModal);
  const correspondingRealtimeRate = rates.find(r => r.bankId === selectedBankIdForModal);

  // Chat message send logic
  const handleSendMessage = async (textToSend?: string) => {
    const text = textToSend || userInput;
    if (!text.trim() || isSendingToAI) return;

    const userMsg: Message = {
      sender: "user",
      text,
      timestamp: new Date().toLocaleTimeString("ru-RU", { hour: "2-digit", minute: "2-digit" })
    };

    setMessages(prev => [...prev, userMsg]);
    if (!textToSend) {
      setUserInput("");
    }
    setIsSendingToAI(true);

    try {
      const response = await fetch("/api/analyze", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ messages: [...messages, userMsg] })
      });
      const data = await response.json();
      
      const assistantMsg: Message = {
        sender: "assistant",
        text: data.text || "Извините, не удалось проанализировать финансовые котировки в данный момент.",
        timestamp: new Date().toLocaleTimeString("ru-RU", { hour: "2-digit", minute: "2-digit" }),
        groundingSources: data.groundingSources
      };
      setMessages(prev => [...prev, assistantMsg]);
    } catch (e) {
      console.log("AI query issue:", String(e));
      const errMsg: Message = {
        sender: "assistant",
        text: "🚨 Произошла ошибка сети при запросе к ИИ-консультанту. Попробуйте нажать кнопку ещё раз.",
        timestamp: new Date().toLocaleTimeString("ru-RU", { hour: "2-digit", minute: "2-digit" })
      };
      setMessages(prev => [...prev, errMsg]);
    } finally {
      setIsSendingToAI(false);
      // Auto scroll
      setTimeout(() => {
        chatBottomRef.current?.scrollIntoView({ behavior: "smooth" });
      }, 50);
    }
  };

  // Custom responsive render of the rates line chart inside an animated SVG with realistic AI Forecasts
  const renderInteractiveChart = () => {
    const paddingLeft = 60;
    const paddingRight = 30;
    const paddingTop = 25;
    const paddingBottom = 35;
    const chartWidth = 520;
    const chartHeight = 175;

    // Pluck values
    const values = historyPoints.map(p => p[selectedCurrency]);
    
    // Simulate realistic AI forecast values next 3 steps
    const lastVal = historyPoints[historyPoints.length - 1][selectedCurrency];
    const stepSize = selectedCurrency === "RUB" || selectedCurrency === "KZT" ? 0.003 : 0.08;
    const forecastVals = [lastVal];
    for (let step = 1; step <= 3; step++) {
      let change = 0;
      if (forecastMode === "growth") {
        change = stepSize * step;
      } else if (forecastMode === "drop") {
        change = -stepSize * step;
      } else {
        // steady/neutral slightly fluctuates
        change = Math.sin(step * 1.5) * stepSize * 0.45;
      }
      forecastVals.push(parseFloat((lastVal + change).toFixed(selectedCurrency === "RUB" || selectedCurrency === "KZT" ? 3 : 2)));
    }

    // Merge both to compute precise bounds
    const allVals = [...values, ...(showForecast ? forecastVals.slice(1) : [])];
    const minVal = Math.min(...allVals) * 0.9995;
    const maxVal = Math.max(...allVals) * 1.0005;
    const delta = maxVal - minVal || 1;

    // Create normalized historical points
    const totalCount = historyPoints.length + (showForecast ? 3 : 0);
    const histPoints = historyPoints.map((p, i) => {
      const x = paddingLeft + (i * (chartWidth - paddingLeft - paddingRight)) / (totalCount - 1);
      const y = chartHeight - paddingBottom - ((p[selectedCurrency] - minVal) / delta) * (chartHeight - paddingTop - paddingBottom);
      return { x, y, label: p.date, val: p[selectedCurrency] };
    });

    // Create normalized forecast points
    const forecastDates = ["Завтра", "+2 дня", "+3 дня"];
    const forePoints = [
      histPoints[histPoints.length - 1], // Start exactly from the last historical point
      ...[1, 2, 3].map((step, i) => {
        const val = forecastVals[step];
        const idx = historyPoints.length - 1 + step;
        const x = paddingLeft + (idx * (chartWidth - paddingLeft - paddingRight)) / (totalCount - 1);
        const y = chartHeight - paddingBottom - ((val - minVal) / delta) * (chartHeight - paddingTop - paddingBottom);
        return { x, y, label: forecastDates[i], val };
      })
    ];

    // Helper to format values
    const formatValue = (v: number) => {
      return v.toFixed(selectedCurrency === "RUB" || selectedCurrency === "KZT" ? 3 : 2);
    };

    // Calculate Y-axis ticks (3 baseline rows)
    const ticksCount = 3;
    const ticks = [];
    for (let i = 0; i < ticksCount; i++) {
      const val = maxVal - (i * (maxVal - minVal)) / (ticksCount - 1);
      const y = paddingTop + (i * (chartHeight - paddingTop - paddingBottom)) / (ticksCount - 1);
      ticks.push({ val, y });
    }

    // Smooth Bezier path generators
    const getSleekPath = (pts: { x: number; y: number }[]) => {
      if (pts.length < 2) return "";
      let path = `M ${pts[0].x} ${pts[0].y}`;
      for (let i = 0; i < pts.length - 1; i++) {
        const p0 = pts[i];
        const p1 = pts[i + 1];
        const cp1x = p0.x + (p1.x - p0.x) / 3;
        const cp1y = p0.y;
        const cp2x = p0.x + (2 * (p1.x - p0.x)) / 3;
        const cp2y = p1.y;
        path += ` C ${cp1x} ${cp1y}, ${cp2x} ${cp2y}, ${p1.x} ${p1.y}`;
      }
      return path;
    };

    const getSleekAreaPath = (pts: { x: number; y: number }[]) => {
      if (pts.length < 2) return "";
      let path = `M ${pts[0].x} ${chartHeight - paddingBottom}`;
      path += ` L ${pts[0].x} ${pts[0].y}`;
      for (let i = 0; i < pts.length - 1; i++) {
        const p0 = pts[i];
        const p1 = pts[i + 1];
        const cp1x = p0.x + (p1.x - p0.x) / 3;
        const cp1y = p0.y;
        const cp2x = p0.x + (2 * (p1.x - p0.x)) / 3;
        const cp2y = p1.y;
        path += ` C ${cp1x} ${cp1y}, ${cp2x} ${cp2y}, ${p1.x} ${p1.y}`;
      }
      path += ` L ${pts[pts.length - 1].x} ${chartHeight - paddingBottom} Z`;
      return path;
    };

    const histPathString = getSleekPath(histPoints);
    const histAreaString = getSleekAreaPath(histPoints);

    const forePathString = getSleekPath(forePoints);
    const foreAreaString = getSleekAreaPath(forePoints);

    // active rate inspecting display data
    const activeDisplay = hoveredPointData || {
      label: "Курс сегодня",
      val: lastVal,
      isForecast: false,
      x: histPoints[histPoints.length - 1].x,
      y: histPoints[histPoints.length - 1].y
    };

    // AI Prognosis justification copy
    let rationale = "";
    if (selectedCurrency === "USD") {
      if (forecastMode === "steady") {
        rationale = "НБКР сохраняет полную интервенционную активность. По прогнозам ИИ на основе анализа новостей, курс наличного доллара продолжит стабильное движение в коридоре 89.15 - 89.40 KGS.";
      } else if (forecastMode === "growth") {
        rationale = "Повышение объемов потребительского импорта и дефицит наличных долларов США в Бишкеке стимулируют умеренный рост котировок до 89.50 KGS.";
      } else {
        rationale = "В связи со стабилизирующими продажами доллара со стороны НБКР и уплатой налогов нерезидентами ожидается временное укрепление сома до 89.15 KGS.";
      }
    } else if (selectedCurrency === "EUR") {
      if (forecastMode === "steady") {
        rationale = "Пара EUR/USD на мировом рынке консолидируется, что предотвращает сильную волатильность наличного евро в центрах обмена Бишкека.";
      } else if (forecastMode === "growth") {
        rationale = "Сезонный туристический спрос и укрепление евро на торгах Forex стимулируют локальный рост курса в обменных пунктах союза.";
      } else {
        rationale = "Снижение процентных ставок со стороны ЕЦБ и отток инвестиционного капитала ослабляют курс наличной европейской валюты к сому.";
      }
    } else if (selectedCurrency === "RUB") {
      if (forecastMode === "steady") {
        rationale = "Российский рубль удерживает плотную линию паритета в коридоре 0.94 - 0.957 KGS при отсутствии сильных шоков.";
      } else if (forecastMode === "growth") {
        rationale = "Рост сырьевых доходов и ограничения на вывод капитала из РФ могут поддержать розничные котировки рубля выше 0.96 KGS.";
      } else {
        rationale = "Адаптивные регуляции рубля Банком России и падение нефтегазового экспорта снижают привлекательность наличного рубля.";
      }
    } else { // KZT
      if (forecastMode === "steady") {
        rationale = "Казахстанский тенге сохраняет стабильное положение при поддержке регулярных трансфертов из Национального фонда РК.";
      } else if (forecastMode === "growth") {
        rationale = "Повышение товарооборота по линии ЕАЭС и рост экспортных платежей стимулируют укрепление тенге до 0.176 сома.";
      } else {
        rationale = "Внутреннее инфляционное давление и ослабление платежного баланса РК ведут к плавной коррекции тенге вниз.";
      }
    }

    return (
      <div className="bg-[#f8fafc] border border-slate-200 rounded-[28px] p-6 shadow-xs relative overflow-hidden dark:bg-slate-900/40 dark:border-slate-800 backdrop-blur-md">
        
        {/* Header containing metadata and control badges */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between mb-5 gap-3">
          <div>
            <div className="flex items-center gap-1.5 flex-wrap">
              <span className="text-[9px] text-slate-450 dark:text-slate-400 font-extrabold tracking-widest uppercase">Хроника изменений и ИИ-Прогноз</span>
              <span className="bg-violet-500/10 dark:bg-violet-400/10 text-violet-600 dark:text-violet-400 px-2 py-0.5 rounded-full font-bold text-[8px] uppercase tracking-wider border border-violet-500/20">
                ИИ-Прогноз
              </span>
            </div>
            <h3 className="text-base font-black text-slate-900 dark:text-white flex items-center gap-1.5 mt-0.5 tracking-tight">
              Динамика и прогноз {selectedCurrency}/KGS
              <span className="text-xs text-blue-600 dark:text-blue-400 font-black font-mono">({currencyDescriptions[selectedCurrency].symbol})</span>
            </h3>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setShowForecast(prev => !prev)}
              className={`text-[10px] font-bold px-3 py-1.5 rounded-xl border transition-all cursor-pointer flex items-center gap-1.5 shadow-3xs ${showForecast ? 'bg-indigo-600 border-indigo-600 text-white hover:bg-indigo-700' : 'bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-550 dark:text-slate-300 hover:bg-slate-50'}`}
            >
              <span className={`w-1.5 h-1.5 rounded-full ${showForecast ? 'bg-amber-300 animate-ping' : 'bg-slate-405'}`} />
              <span>Линия прогноза: {showForecast ? "Вкл" : "Выкл"}</span>
            </button>
          </div>
        </div>

        {/* Real-time coordinates inspection status bar */}
        <div className="grid grid-cols-2 bg-white dark:bg-slate-950/80 border border-slate-100 dark:border-slate-850 rounded-2xl p-3 mb-4 shadow-3xs gap-2 transition-all duration-200">
          <div>
            <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest block">ПЕРИОД И КАТЕГОРИЯ</span>
            <div className="flex items-center gap-1.5 mt-0.5">
              <span className="text-xs font-black text-slate-800 dark:text-white">{activeDisplay.label}</span>
              {activeDisplay.isForecast ? (
                <span className="bg-violet-600 text-white text-[7px] font-black tracking-wider px-1.5 py-0.5 rounded-md uppercase">Прогноз</span>
              ) : (
                <span className="bg-blue-600 text-white text-[7px] font-black tracking-wider px-1.5 py-0.5 rounded-md uppercase">Рынок наличных</span>
              )}
            </div>
          </div>
          <div className="text-right">
            <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest block">КУРС (СОМ)</span>
            <span className="text-sm font-black text-blue-600 dark:text-blue-400 font-mono block mt-0.5">
              {formatValue(activeDisplay.val)} KGS
            </span>
          </div>
        </div>

        {/* SVG Drawing Canvas */}
        <div className="relative h-44 w-full bg-white dark:bg-slate-950 rounded-2xl border border-slate-100/80 dark:border-slate-900 shadow-3xs p-1">
          <svg className="w-full h-full" viewBox={`0 0 ${chartWidth} ${chartHeight}`} preserveAspectRatio="none">
            <defs>
              <linearGradient id="chartGrad" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#2563eb" stopOpacity="0.12" />
                <stop offset="100%" stopColor="#2563eb" stopOpacity="0.0" />
              </linearGradient>
              <linearGradient id="forecastGrad" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#8b5cf6" stopOpacity={isDarkMode ? "0.22" : "0.14"} />
                <stop offset="100%" stopColor="#8b5cf6" stopOpacity="0.0" />
              </linearGradient>
              <linearGradient id="foreLineGrad" x1="0" y1="0" x2="1" y2="0">
                <stop offset="0%" stopColor={isDarkMode ? "#3b82f6" : "#2563eb"} />
                <stop offset="100%" stopColor={isDarkMode ? "#c084fc" : "#8b5cf6"} />
              </linearGradient>
            </defs>

            {/* Horizontal Grid lines with dynamic Y-axis label text */}
            {ticks.map((tick, i) => (
              <g key={`tick-${i}`}>
                <line
                  x1={paddingLeft}
                  y1={tick.y}
                  x2={chartWidth - paddingRight}
                  y2={tick.y}
                  stroke={isDarkMode ? "#334155" : "#e2e8f0"}
                  strokeWidth="1"
                  strokeDasharray="4,4"
                />
                <text
                  x={paddingLeft - 8}
                  y={tick.y + 3}
                  className="fill-slate-500 dark:fill-slate-350 font-mono text-[9px] font-bold"
                  textAnchor="end"
                >
                  {formatValue(tick.val)}
                </text>
              </g>
            ))}

            {/* Area under curve (Historical) */}
            <path d={histAreaString} fill="url(#chartGrad)" />

            {/* Area under curve (Forecast) */}
            {showForecast && (
              <path d={foreAreaString} fill="url(#forecastGrad)" />
            )}

            {/* Decoupled Vector Glow Paths */}
            <path d={histPathString} fill="none" stroke="#2563eb" strokeWidth="6" strokeLinecap="round" opacity="0.08" />
            
            {showForecast && (
              <path d={forePathString} fill="none" stroke="url(#foreLineGrad)" strokeWidth="8" strokeLinecap="round" opacity={isDarkMode ? "0.22" : "0.14"} />
            )}

            {/* Main historical spline path */}
            <path d={histPathString} fill="none" stroke="#2563eb" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />

            {/* AI Forecast dotted spline path */}
            {showForecast && (
              <>
                {/* Thin undertow solid connector line with gradient transition */}
                <path
                  d={forePathString}
                  fill="none"
                  stroke="url(#foreLineGrad)"
                  strokeWidth="1.5"
                  opacity="0.25"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
                {/* Crisp neon glowing dashed forecast line with gradient transition */}
                <path
                  d={forePathString}
                  fill="none"
                  stroke="url(#foreLineGrad)"
                  strokeWidth="2.5"
                  strokeDasharray="6,4"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
              </>
            )}

            {/* Hover vertical cursor guide */}
            {hoveredPointData && (
              <line
                x1={hoveredPointData.x}
                y1={paddingTop - 5}
                x2={hoveredPointData.x}
                y2={chartHeight - paddingBottom + 5}
                stroke="#3b82f6"
                strokeDasharray="3,3"
                strokeWidth="1.2"
                opacity="0.4"
                className="dark:stroke-blue-400"
              />
            )}

            {/* Render Historical Dots and Interactive Event Anchors */}
            {histPoints.map((p, idx) => (
              <g
                key={`hist-${idx}`}
                onMouseEnter={() => setHoveredPointData({ x: p.x, y: p.y, label: p.label, val: p.val, isForecast: false })}
                onMouseLeave={() => setHoveredPointData(null)}
                className="group cursor-pointer"
              >
                {/* Glow ring on hover */}
                <circle
                  cx={p.x}
                  cy={p.y}
                  r="7"
                  className="fill-blue-500 opacity-0 group-hover:opacity-20 transition-all duration-150"
                />
                <circle
                  cx={p.x}
                  cy={p.y}
                  r="4"
                  className="fill-white stroke-blue-600 group-hover:scale-125 transition-all duration-200 shadow-sm dark:stroke-blue-400 dark:fill-slate-950"
                  strokeWidth="2"
                />
                
                {/* Dates ticks along bottom line */}
                {idx % 2 === 0 && (
                  <text
                    x={p.x}
                    y={chartHeight - 12}
                    className="fill-slate-500 dark:fill-slate-350 font-sans text-[8px] font-bold"
                    textAnchor="middle"
                  >
                    {p.label}
                  </text>
                )}
              </g>
            ))}

            {/* Render AI Forecast Dots and Interactive Event Anchors */}
            {showForecast && forePoints.slice(1).map((p, idx) => (
              <g
                key={`fore-${idx}`}
                onMouseEnter={() => setHoveredPointData({ x: p.x, y: p.y, label: p.label, val: p.val, isForecast: true })}
                onMouseLeave={() => setHoveredPointData(null)}
                className="group cursor-pointer"
              >
                {/* Permanent subtle breathing halo for AI forecast points */}
                <circle
                  cx={p.x}
                  cy={p.y}
                  r="7.5"
                  className="fill-violet-400/25 dark:fill-violet-500/20 animate-pulse"
                />
                
                {/* Glow ring on hover */}
                <circle
                  cx={p.x}
                  cy={p.y}
                  r="11"
                  className="fill-violet-500 opacity-0 group-hover:opacity-20 transition-all duration-150"
                />
                
                <circle
                  cx={p.x}
                  cy={p.y}
                  r="4"
                  className="fill-white stroke-violet-500 group-hover:scale-125 transition-all duration-200 shadow-sm dark:stroke-violet-400 dark:fill-slate-950"
                  strokeWidth="2.2"
                />

                {/* Floating exact exchange rate number capsule above the dot */}
                <g className="transition-all duration-200 group-hover:-translate-y-1">
                  {/* Capsule background shadow wrapper */}
                  <rect
                    x={p.x - 22}
                    y={p.y - 21}
                    width="44"
                    height="13.5"
                    rx="4.5"
                    className="fill-white dark:fill-slate-900 stroke-violet-200 dark:stroke-violet-850 shadow-2xs brightness-95"
                    strokeWidth="1"
                  />
                  <text
                    x={p.x}
                    y={p.y - 11.5}
                    className="fill-violet-700 dark:fill-violet-400 font-mono text-[8px] font-black tracking-tight"
                    textAnchor="middle"
                  >
                    {formatValue(p.val)}
                  </text>
                </g>

                {/* Forecast date labels */}
                <text
                  x={p.x}
                  y={chartHeight - 12}
                  className="fill-violet-600 dark:fill-violet-400 font-sans text-[8px] font-extrabold"
                  textAnchor="middle"
                >
                  {p.label}
                </text>
              </g>
            ))}
          </svg>
        </div>

        {/* Legend block illustrating chart lines */}
        <div className="flex flex-wrap items-center justify-center gap-x-6 gap-y-2 mt-3 px-3 py-2 bg-slate-50/50 dark:bg-slate-950/20 border border-slate-150/40 dark:border-slate-850/50 rounded-2xl text-[10px] font-bold text-slate-550 dark:text-slate-400">
          <div className="flex items-center gap-2">
            <svg className="w-8 h-2 shrink-0 overflow-visible" viewBox="0 0 32 8">
              {/* Glow background line */}
              <line x1="0" y1="4" x2="32" y2="4" stroke="#2563eb" strokeWidth="4" opacity="0.12" strokeLinecap="round" />
              {/* Main solid line */}
              <line x1="0" y1="4" x2="32" y2="4" stroke="#2563eb" strokeWidth="2" strokeLinecap="round" />
              {/* Central point indicator */}
              <circle cx="16" cy="4" r="3" className="fill-white stroke-blue-600 dark:stroke-blue-400 dark:fill-slate-950" strokeWidth="1.5" />
            </svg>
            <span className="font-sans">История изменений (рыночный курс)</span>
          </div>

          {showForecast && (
            <div className="flex items-center gap-2 animate-fade-in">
              <svg className="w-8 h-2 shrink-0 overflow-visible" viewBox="0 0 32 8">
                {/* Glow purple background line */}
                <line x1="0" y1="4" x2="32" y2="4" stroke={isDarkMode ? "#c084fc" : "#8b5cf6"} strokeWidth="5" opacity="0.16" strokeLinecap="round" />
                {/* Dashed line */}
                <line x1="0" y1="4" x2="32" y2="4" stroke={isDarkMode ? "#c084fc" : "#8b5cf6"} strokeWidth="2" strokeDasharray="4,2.5" strokeLinecap="round" />
                {/* Pulsing forecast indicator point */}
                <circle cx="16" cy="4" r="4.5" className="fill-violet-400/25 dark:fill-violet-500/20 animate-pulse" />
                <circle cx="16" cy="4" r="3" className="fill-white stroke-violet-500 dark:stroke-violet-400 dark:fill-slate-950" strokeWidth="1.8" />
              </svg>
              <span className="text-violet-600 dark:text-violet-400 font-sans">ИИ-Прогноз (перспективный тренд)</span>
            </div>
          )}
        </div>

        {/* Forecast interactive controllers & Rationale */}
        <div className="mt-4 border-t border-slate-100 dark:border-slate-850 pt-4 space-y-4">
          
          {/* Tabs for forecasting vector */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 flex-wrap bg-white dark:bg-slate-950/45 p-2 rounded-2xl border border-slate-100 dark:border-slate-850/50">
            <span className="text-[9px] text-slate-450 dark:text-slate-400 font-extrabold tracking-wider uppercase ml-1">Сценарий ИИ-гипотезы:</span>
            
            <div className="flex items-center gap-1 bg-slate-100/80 dark:bg-slate-900 p-1 rounded-xl shrink-0">
              <button
                onClick={() => setForecastMode("steady")}
                className={`text-[10px] font-extrabold px-3 py-1.5 rounded-lg transition-all cursor-pointer ${forecastMode === "steady" ? 'bg-white dark:bg-slate-800 text-slate-850 dark:text-white shadow-3xs' : 'text-slate-400 hover:text-slate-650'}`}
              >
                📊 Боковик
              </button>
              <button
                onClick={() => setForecastMode("growth")}
                className={`text-[10px] font-extrabold px-3 py-1.5 rounded-lg transition-all cursor-pointer ${forecastMode === "growth" ? 'bg-emerald-600 text-white shadow-3xs' : 'text-slate-400 hover:text-slate-650'}`}
              >
                📈 Рост курса
              </button>
              <button
                onClick={() => setForecastMode("drop")}
                className={`text-[10px] font-extrabold px-3 py-1.5 rounded-lg transition-all cursor-pointer ${forecastMode === "drop" ? 'bg-rose-600 text-white shadow-3xs' : 'text-slate-400 hover:text-slate-650'}`}
              >
                📉 Коррекция
              </button>
            </div>
          </div>

          {/* AI Justification Display Panel */}
          {showForecast && (
            <div className="bg-violet-500/[0.03] dark:bg-violet-500/[0.015] border border-violet-550/15 dark:border-violet-500/10 p-4 rounded-2xl flex gap-3 items-start transition-all duration-350">
              <Sparkles className="w-4 h-4 text-violet-500 dark:text-violet-400 shrink-0 mt-0.5 animate-pulse" />
              <div className="space-y-1">
                <span className="text-[9px] font-black text-violet-600 dark:text-violet-400 uppercase tracking-widest block font-sans">АНАЛИТИЧЕСКИЙ ПРОГНОЗ МОДЕЛИ ИИ</span>
                <p className="text-xs text-slate-650 dark:text-slate-350 leading-relaxed font-semibold">
                  {rationale}
                </p>
              </div>
            </div>
          )}

          <div className="flex justify-between items-center text-[10px] text-slate-450 dark:text-slate-500 font-bold font-mono px-1 flex-wrap gap-2">
            <div className="flex items-center gap-1.5">
              <span className={`w-2 h-2 rounded-full ${forecastMode === 'growth' ? 'bg-emerald-500 animate-pulse' : forecastMode === 'drop' ? 'bg-rose-500 animate-pulse' : 'bg-violet-500 animate-pulse'}`} />
              Текущий тренд: <strong className={`font-bold uppercase ${forecastMode === 'growth' ? 'text-emerald-600 dark:text-emerald-400' : forecastMode === 'drop' ? 'text-rose-600 dark:text-rose-400' : 'text-violet-600 dark:text-violet-400'}`}>{forecastMode === "steady" ? "Боковое накопление" : forecastMode === "growth" ? "Бычий разгон" : "Коррекционная отметка"}</strong>
            </div>
            <div className="bg-slate-100 dark:bg-slate-950 px-2.5 py-1 rounded-lg border border-slate-200/50 dark:border-slate-800 text-[9px]">
              Коридор прогноза: <span className="text-violet-600 dark:text-violet-400 font-black">{formatValue(minVal)}</span> – <span className="text-violet-600 dark:text-violet-400 font-black">{formatValue(maxVal)}</span> <span className="font-sans font-bold">KGS</span>
            </div>
          </div>
        </div>
      </div>
    );
  };

  const renderBankLogo = (bankId: string, name: string) => {
    let bgClass = "bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-350";
    let text = name ? name.substring(0, 3).toUpperCase() : "БНК";
    
    if (bankId === "mbank") {
      bgClass = "bg-[#111111] text-[#2de100] border border-[#2de100]/25 font-black";
      text = "M";
    } else if (bankId === "bakai") {
      bgClass = "bg-[#137b80] text-white font-extrabold";
      text = "B";
    } else if (bankId === "optima") {
      bgClass = "bg-[#e30613] text-white font-extrabold";
      text = "O";
    } else if (bankId === "demir") {
      bgClass = "bg-[#002e5f] text-white font-semibold";
      text = "D";
    } else if (bankId === "eldik") {
      bgClass = "bg-[#0a4d33] text-white font-semibold";
      text = "E";
    } else if (bankId === "aiyl") {
      bgClass = "bg-[#15803d] text-white font-semibold";
      text = "A";
    } else if (bankId === "kicb") {
      bgClass = "bg-[#0f172a] text-[#38bdf8] font-bold";
      text = "KIC";
    } else if (bankId === "finca") {
      bgClass = "bg-[#4f46e5] text-white font-bold";
      text = "FIN";
    } else if (bankId === "doscredo") {
      bgClass = "bg-[#9b1c31] text-white font-bold";
      text = "DCB";
    } else if (bankId === "kompanion") {
      bgClass = "bg-[#7cb342] text-white font-bold";
      text = "КОМ";
    } else if (bankId === "keramet") {
      bgClass = "bg-[#0284c7] text-white font-bold";
      text = "КРМ";
    } else if (bankId === "baitushum") {
      bgClass = "bg-[#ea580c] text-white font-bold";
      text = "БТШ";
    } else if (bankId === "halyk") {
      bgClass = "bg-[#0f766e] text-white font-bold";
      text = "ХАЛ";
    }

    return (
      <div className={`w-10 h-10 rounded-xl flex items-center justify-center font-bold text-xs tracking-wider shadow-sm select-none ${bgClass}`}>
        {text}
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-[#f8fafc] dark:bg-[#0b1329] font-sans text-slate-900 dark:text-slate-100 flex flex-col antialiased transition-colors duration-250" id="app-root">
      {/* Top Premium Hub Header */}
      <header className="border-b border-slate-200/65 dark:border-slate-850 bg-white/95 dark:bg-[#0e1730]/95 backdrop-blur-md sticky top-0 z-40 shadow-2xs">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="bg-blue-600 dark:bg-blue-600 p-2.5 rounded-xl text-white flex items-center justify-center shadow-xs shadow-blue-550/15">
              <ArrowRightLeft className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-base font-extrabold tracking-tight text-slate-900 dark:text-white">
                  Valuta.kg
                </span>
                <span className="h-4.5 w-px bg-slate-200 dark:bg-slate-800" />
                <span className="text-xs font-bold text-slate-500 dark:text-slate-400 tracking-normal font-sans">
                  Терминал КР
                </span>
              </div>
              <p className="text-[10px] text-slate-400 dark:text-slate-500 font-semibold tracking-wide uppercase mt-0.5">Мониторинг курсов валют, кредитов и вкладов</p>
            </div>
          </div>

          <nav className="hidden md:flex items-center gap-1 bg-slate-100/80 dark:bg-slate-950/40 p-1 rounded-xl border border-slate-200/40 dark:border-slate-800/40">
            <button
              onClick={() => setActiveTab("rates")}
              className={`px-4 py-2 text-xs font-bold rounded-lg transition-all flex items-center gap-1.5 ${
                activeTab === "rates"
                  ? "bg-white dark:bg-slate-800 text-blue-600 dark:text-blue-400 border border-slate-200/10 dark:border-slate-755 shadow-xs"
                  : "text-slate-550 hover:text-slate-900 dark:text-slate-400 dark:hover:text-slate-200 hover:bg-white/45 dark:hover:bg-[#1a2544]/50"
              }`}
            >
              <span>Курсы валют</span>
              <kbd className="hidden lg:inline-block px-1 py-0.5 text-[8.5px] font-black font-mono rounded-md border bg-slate-50 dark:bg-slate-900 border-slate-200/60 dark:border-slate-700/80 text-slate-400">Ctrl+1</kbd>
            </button>
            <button
              onClick={() => setActiveTab("banks")}
              className={`px-4 py-2 text-xs font-bold rounded-lg transition-all flex items-center gap-1.5 ${
                activeTab === "banks"
                  ? "bg-white dark:bg-slate-800 text-blue-600 dark:text-blue-400 border border-slate-200/10 dark:border-slate-755 shadow-xs"
                  : "text-slate-550 hover:text-slate-900 dark:text-slate-400 dark:hover:text-slate-200 hover:bg-white/45 dark:hover:bg-[#1a2544]/50"
              }`}
            >
              <span>Сайты банков КР</span>
              <kbd className="hidden lg:inline-block px-1 py-0.5 text-[8.5px] font-black font-mono rounded-md border bg-slate-50 dark:bg-slate-900 border-slate-200/60 dark:border-slate-700/80 text-slate-400">Ctrl+2</kbd>
            </button>
            <button
              onClick={() => setActiveTab("loans")}
              className={`px-4 py-2 text-xs font-bold rounded-lg transition-all flex items-center gap-1.5 ${
                activeTab === "loans"
                  ? "bg-white dark:bg-slate-800 text-blue-600 dark:text-blue-400 border border-slate-200/10 dark:border-slate-755 shadow-xs"
                  : "text-slate-550 hover:text-slate-900 dark:text-slate-400 dark:hover:text-slate-200 hover:bg-white/45 dark:hover:bg-[#1a2544]/50"
              }`}
            >
              <span>Кредиты КР</span>
              <kbd className="hidden lg:inline-block px-1 py-0.5 text-[8.5px] font-black font-mono rounded-md border bg-slate-50 dark:bg-slate-900 border-slate-200/60 dark:border-slate-700/80 text-slate-400">Ctrl+3</kbd>
            </button>
            <button
              onClick={() => setActiveTab("deposits")}
              className={`px-4 py-2 text-xs font-bold rounded-lg transition-all flex items-center gap-1.5 ${
                activeTab === "deposits"
                  ? "bg-white dark:bg-slate-800 text-blue-600 dark:text-blue-400 border border-slate-200/10 dark:border-slate-755 shadow-xs"
                  : "text-slate-550 hover:text-slate-900 dark:text-slate-400 dark:hover:text-slate-200 hover:bg-white/45 dark:hover:bg-[#1a2544]/50"
              }`}
            >
              <span>Депозиты КР</span>
              <kbd className="hidden lg:inline-block px-1 py-0.5 text-[8.5px] font-black font-mono rounded-md border bg-slate-50 dark:bg-slate-900 border-slate-200/60 dark:border-slate-700/80 text-slate-400">Ctrl+4</kbd>
            </button>
          </nav>

          <div className="flex items-center gap-2.5">
            {/* Theme Toggle Button */}
            <button
              id="theme-toggle-btn"
              onClick={() => {
                setIsDarkMode(prev => !prev);
                showToast(!isDarkMode ? "🌙 Включена темная тема" : "☀️ Включена светлая тема");
              }}
              className="p-2.5 bg-slate-100 hover:bg-slate-200 text-slate-705 dark:bg-slate-900 dark:hover:bg-slate-800 dark:text-slate-350 rounded-xl border border-slate-200/60 dark:border-slate-800 transition-all flex items-center justify-center cursor-pointer shadow-3xs"
              title={isDarkMode ? "Перейти на светлую тему" : "Перейти на темную тему"}
            >
              {isDarkMode ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4 text-slate-600" />}
            </button>

            <button
              onClick={() => {
                fetchRates(true);
                showToast("🔮 Синхронизация курсов валют начата...");
              }}
              disabled={isLoadingRates}
              className="flex items-center gap-1.5 bg-slate-950 hover:bg-slate-900 dark:bg-white dark:hover:bg-slate-50 text-white dark:text-slate-950 px-4 py-2.5 rounded-xl text-xs font-bold transition-all disabled:opacity-50 shadow-xs cursor-pointer border border-slate-200 dark:border-transparent"
            >
              <Sparkles className="w-3.5 h-3.5 text-amber-500 animate-pulse" />
              <span>Синхронизировать ИИ</span>
            </button>
          </div>
        </div>
      </header>

      {/* Main Container Layout */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left Side: Dynamic Tables, Calculators and Bank Directories (8 Columns on desktop) */}
        <section className="lg:col-span-8 space-y-6">

          {/* Quick Info Bar */}
          <div className="bg-white dark:bg-[#0f172a] border border-slate-200/80 dark:border-slate-800/80 rounded-2xl p-4.5 flex flex-col md:flex-row items-start md:items-center justify-between gap-4 shadow-3xs">
            <div className="flex items-center gap-3.5">
              <div className="w-9 h-9 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-100 dark:border-slate-800 flex items-center justify-center shadow-xs">
                <RefreshCcw className={`w-3.5 h-3.5 text-blue-600 dark:text-blue-400 ${isLoadingRates ? 'animate-spin' : ''}`} />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className="relative flex h-2 w-2">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                    <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
                  </span>
                  <span className="text-xs text-slate-700 dark:text-slate-200 font-bold tracking-wide uppercase">{ratesSource}</span>
                </div>
                <p className="text-[11px] text-slate-400 dark:text-slate-500 font-medium mt-0.5 md:mt-0">Интеграция с valuta.kg: автообновление рынка через <span className="font-mono text-slate-700 dark:text-slate-300 font-bold">{countdown} с</span></p>
              </div>
            </div>
            
            <div className="flex gap-1 bg-slate-100/80 dark:bg-slate-950/80 p-1 rounded-xl border border-slate-200/60 dark:border-slate-850 self-stretch md:self-auto overflow-x-auto">
              {(["USD", "EUR", "RUB", "KZT"] as const).map(curr => (
                <button
                  key={curr}
                  onClick={() => {
                    setSelectedCurrency(curr);
                    showToast(`💱 Мониторинг котировок переключен на ${currencyDescriptions[curr].nameRu} (${curr})`);
                  }}
                  className={`px-4 py-2 text-xs font-mono font-bold rounded-lg transition-all cursor-pointer ${
                    selectedCurrency === curr
                      ? "bg-white dark:bg-slate-800 text-blue-600 dark:text-blue-400 border border-slate-200/10 dark:border-slate-700/30 shadow-xs"
                      : "text-slate-500 hover:text-slate-800 dark:hover:text-slate-300 hover:bg-white/40 dark:hover:bg-slate-900/50"
                  }`}
                >
                  {curr}
                </button>
              ))}
            </div>

          </div>
            
          {/* Sleek Bank Comparison Quick-Bar */}
          <div className="bg-gradient-to-r from-blue-600 to-indigo-700 dark:from-slate-900 dark:to-slate-850 p-5 rounded-[24px] text-white shadow-xs border border-slate-200 dark:border-slate-800 space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <h3 className="text-sm font-extrabold flex items-center gap-2">
                  <Scale className="w-4 h-4 text-amber-400" />
                  Интеллектуальное сопоставление условий банков КР
                </h3>
                <p className="text-[11px] text-blue-105 dark:text-slate-400 mt-1 font-medium leading-relaxed">
                  Выберите два любых коммерческих банка Бишкека для мгновенного наглядного сравнения ставок кредитования, процентов вкладов и обмена валют.
                </p>
              </div>
              <button
                onClick={() => setIsCompareModalOpen(true)}
                className="bg-white hover:bg-slate-50 text-blue-700 dark:bg-blue-600 dark:hover:bg-blue-750 dark:text-white font-extrabold text-xs px-4.5 py-2.5 rounded-xl transition-all self-start sm:self-auto shadow-xs cursor-pointer flex items-center gap-1.5 shrink-0"
              >
                <span>Начать сравнение</span>
                <ChevronRight className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5 pt-1">
              <div className="space-y-1 bg-white/10 dark:bg-slate-950/40 border border-white/10 dark:border-slate-800/80 p-3 rounded-2xl">
                <label className="text-[9px] uppercase tracking-wider font-extrabold text-blue-100 dark:text-slate-400 block mb-1">Банк А (для сопоставления)</label>
                <div className="flex items-center gap-2">
                  <div className="w-6 h-6 rounded-lg bg-white/20 text-white font-black text-[9px] flex items-center justify-center shrink-0 font-mono">
                    {compareBankIdA.substring(0, 3).toUpperCase()}
                  </div>
                  <select
                    value={compareBankIdA}
                    onChange={(e) => setCompareBankIdA(e.target.value)}
                    className="bg-transparent text-xs font-bold text-white focus:outline-none w-full cursor-pointer dark:text-slate-200"
                  >
                    {defaultBanksList.map(b => (
                      <option key={b.id} value={b.id} className="text-slate-900 bg-white font-bold">{b.nameRu}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="space-y-1 bg-white/10 dark:bg-slate-950/40 border border-white/10 dark:border-slate-800/80 p-3 rounded-2xl">
                <label className="text-[9px] uppercase tracking-wider font-extrabold text-blue-100 dark:text-slate-400 block mb-1">Банк Б (для сопоставления)</label>
                <div className="flex items-center gap-2">
                  <div className="w-6 h-6 rounded-lg bg-white/20 text-white font-black text-[9px] flex items-center justify-center shrink-0 font-mono">
                    {compareBankIdB.substring(0, 3).toUpperCase()}
                  </div>
                  <select
                    value={compareBankIdB}
                    onChange={(e) => setCompareBankIdB(e.target.value)}
                    className="bg-transparent text-xs font-bold text-white focus:outline-none w-full cursor-pointer dark:text-slate-200"
                  >
                    {defaultBanksList.map(b => (
                      <option key={b.id} value={b.id} className="text-slate-900 bg-white font-bold">{b.nameRu}</option>
                    ))}
                  </select>
                </div>
              </div>
            </div>
          </div>
            


          {/* Mobile Navigation Dropdown Bar (Only visible on mobile screens) */}
          <div className="md:hidden flex bg-slate-100/80 p-1 rounded-xl border border-slate-200 justify-between items-center">
            <button
              onClick={() => setActiveTab("rates")}
              className={`flex-1 py-2 text-[11px] font-bold text-center rounded-lg transition-all ${
                activeTab === "rates" ? "bg-white text-blue-600 border border-slate-200 shadow-xs" : "text-slate-500"
              }`}
            >
              Курсы
            </button>
            <button
              onClick={() => setActiveTab("banks")}
              className={`flex-1 py-2 text-[11px] font-bold text-center rounded-lg transition-all ${
                activeTab === "banks" ? "bg-white text-blue-600 border border-slate-200 shadow-xs" : "text-slate-500"
              }`}
            >
              Сайты
            </button>
            <button
              onClick={() => setActiveTab("loans")}
              className={`flex-1 py-2 text-[11px] font-bold text-center rounded-lg transition-all ${
                activeTab === "loans" ? "bg-white text-blue-600 border border-slate-200 shadow-xs" : "text-slate-500"
              }`}
            >
              Кредиты
            </button>
            <button
              onClick={() => setActiveTab("deposits")}
              className={`flex-1 py-2 text-[11px] font-bold text-center rounded-lg transition-all ${
                activeTab === "deposits" ? "bg-white text-blue-600 border border-slate-200 shadow-xs" : "text-slate-500"
              }`}
            >
              Вклады
            </button>
          </div>

          {/* Content Pane of selected tab */}
          {activeTab === "rates" && (
            <div className="space-y-6">
              
              {/* Filter, Search & Sorting Options on Rates */}
              <div className="bg-white border border-slate-200 rounded-[24px] p-5 space-y-4 shadow-xs">
                <div className="flex flex-col sm:flex-row gap-3">
                  <div className="relative flex-1">
                    <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                    <input
                      type="text"
                      placeholder="Поиск банка (например, Бакай, Оптима)..."
                      value={searchBankQuery}
                      onChange={e => setSearchBankQuery(e.target.value)}
                      className="w-full bg-slate-50 border border-slate-200 text-slate-800 placeholder-slate-400 pl-10 pr-4 py-2.5 h-11 rounded-xl text-xs focus:outline-none focus:ring-2 focus:ring-blue-100/50 focus:border-blue-500 transition-all font-medium"
                    />
                    {searchBankQuery && (
                      <button
                        onClick={() => setSearchBankQuery("")}
                        className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-700"
                      >
                        <X className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>

                  <div className="flex items-center gap-2">
                    <span className="text-[11px] text-slate-400 font-bold font-mono whitespace-nowrap uppercase tracking-wider">Сортировать:</span>
                    <button
                      onClick={() => handleBankSort("buy")}
                      className={`text-xs px-3.5 py-2.5 border rounded-xl flex items-center gap-1.5 transition-all cursor-pointer font-bold ${
                        sortField === "buy"
                          ? "bg-blue-50 border-blue-200 text-blue-600 shadow-xs"
                          : "bg-slate-50 border-slate-200 text-slate-500 hover:text-slate-800 hover:bg-slate-100"
                      }`}
                    >
                      <span>Покупка</span>
                      {sortField === "buy" ? (sortOrder === "desc" ? "↓" : "↑") : ""}
                    </button>
                    <button
                      onClick={() => handleBankSort("sell")}
                      className={`text-xs px-3.5 py-2.5 border rounded-xl flex items-center gap-1.5 transition-all cursor-pointer font-bold ${
                        sortField === "sell"
                          ? "bg-blue-50 border-blue-200 text-blue-600 shadow-xs"
                          : "bg-slate-50 border-slate-200 text-slate-500 hover:text-slate-800 hover:bg-slate-100"
                      }`}
                    >
                      <span>Продажа</span>
                      {sortField === "sell" ? (sortOrder === "desc" ? "↓" : "↑") : ""}
                    </button>
                  </div>
                </div>

                {/* Extreme rates quick recommendation summary bar */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-3 border-t border-slate-100">
                  <div className="bg-emerald-50/60 p-4 rounded-2xl border border-emerald-100/70 flex items-center justify-between shadow-xs">
                    <div>
                      <h4 className="text-[10px] text-emerald-600 font-extrabold uppercase tracking-widest">Макс. покупка KGS</h4>
                      <div className="text-xl font-extrabold text-emerald-900 mt-0.5">{maxBuy.toFixed(selectedCurrency === 'RUB' || selectedCurrency === 'KZT' ? 3 : 2)} сом</div>
                    </div>
                    <span className="text-[10px] font-bold bg-[#10b981] text-white px-2.5 py-1 rounded-lg shadow-xs">Сдать дороже</span>
                  </div>
                  <div className="bg-blue-50/60 p-4 rounded-2xl border border-blue-100/70 flex items-center justify-between shadow-xs">
                    <div>
                      <h4 className="text-[10px] text-blue-600 font-extrabold uppercase tracking-widest">Мин. продажа KGS</h4>
                      <div className="text-xl font-extrabold text-blue-900 mt-0.5">{minSell.toFixed(selectedCurrency === 'RUB' || selectedCurrency === 'KZT' ? 3 : 2)} сом</div>
                    </div>
                    <span className="text-[10px] font-bold bg-blue-600 text-white px-2.5 py-1 rounded-lg shadow-xs">Купить дешевле</span>
                  </div>
                </div>
              </div>

              {/* Central Rates Table */}
              <div className="bg-white border border-slate-200 rounded-[28px] overflow-hidden shadow-xs">
                <div className="p-6 border-b border-slate-150 flex justify-between items-center bg-white">
                  <h3 className="text-base font-extrabold text-slate-950 flex items-center gap-2">
                    <Building2 className="w-5 h-5 text-blue-600" />
                    Курсы обмена в банках Бишкека
                  </h3>
                  <span className="text-xs text-slate-500 font-bold bg-slate-100 px-2.5 py-1 rounded-lg">Валюта: сом (KGS)</span>
                </div>

                {isLoadingRates && rates.length === 0 ? (
                  <div className="py-20 flex flex-col items-center justify-center gap-3">
                    <RefreshCcw className="w-8 h-8 text-blue-600 animate-spin" />
                    <p className="text-xs text-slate-500 font-medium">Получение последних курсов с valuta.kg...</p>
                  </div>
                ) : (
                  <div className="overflow-x-auto">
                    <table className="w-full text-left border-collapse">
                      <thead>
                        <tr className="border-b border-slate-200 bg-slate-50 text-[10px] font-bold font-sans text-slate-500 uppercase tracking-widest">
                          <th className="py-4 px-6">Коммерческий Банк</th>
                          <th className="py-4 px-6 text-right">Покупка ({selectedCurrency})</th>
                          <th className="py-4 px-6 text-right">Продажа ({selectedCurrency})</th>
                          <th className="py-4 px-6 text-center">Детали</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100">
                        {filteredRatesAndBanks.map((item, idx) => {
                          const rateItem = item.rates[selectedCurrency];
                          const isMaxBuy = rateItem.buy === maxBuy;
                          const isMinSell = rateItem.sell === minSell;
                          const isFav = favoriteBankIds.includes(item.bankId);

                          return (
                            <tr
                              key={item.bankId}
                              className={`transition-colors group cursor-pointer ${
                                isFav 
                                  ? "bg-amber-500/[0.025] dark:bg-amber-400/[0.015] hover:bg-amber-500/[0.05] dark:hover:bg-amber-400/[0.03] border-l-4 border-amber-400" 
                                  : "hover:bg-slate-50/70"
                              }`}
                              onClick={() => setSelectedBankIdForModal(item.bankId)}
                            >
                              <td className="py-4 px-6 flex items-center gap-3">
                                <button
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    toggleFavorite(item.bankId);
                                  }}
                                  className="p-1 hover:scale-115 active:scale-95 transition-all text-slate-350 hover:text-amber-500 dark:text-slate-600 dark:hover:text-amber-450 focus:outline-none shrink-0 cursor-pointer"
                                  title={isFav ? "Убрать из избранного" : "Добавить в избранное"}
                                >
                                  <Star className={`w-4 h-4 ${isFav ? "fill-amber-450 text-amber-500" : "text-slate-300 dark:text-slate-600"}`} />
                                </button>
                                {renderBankLogo(item.bankId, item.bankNameRu)}
                                <div>
                                  <div className="text-sm font-bold text-slate-800 dark:text-white group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors flex items-center gap-1.5">
                                    {item.bankNameRu}
                                    <ChevronRight className="w-3.5 h-3.5 text-slate-400 opacity-0 group-hover:opacity-100 transition-all" />
                                  </div>
                                  <div className="text-[10px] text-slate-400 dark:text-slate-500 font-semibold font-mono mt-0.5">{item.website.replace("https://", "")}</div>
                                </div>
                              </td>
                              
                              <td className="py-4 px-6 text-right">
                                <div className="flex items-center justify-end gap-1.5">
                                  {rateItem.buyChange === 'up' && <TrendingUp className="w-4 h-4 text-emerald-500 animate-pulse" />}
                                  {rateItem.buyChange === 'down' && <TrendingDown className="w-4 h-4 text-red-500" />}
                                  <span className={`text-xs font-mono font-bold py-1 px-2 rounded-lg ${
                                    isMaxBuy ? "text-emerald-700 bg-emerald-50 border border-emerald-100 font-extrabold shadow-2xs" : "text-slate-700"
                                  }`}>
                                    {rateItem.buy.toFixed(selectedCurrency === 'RUB' || selectedCurrency === 'KZT' ? 3 : 2)}
                                  </span>
                                </div>
                              </td>

                              <td className="py-4 px-6 text-right">
                                <div className="flex items-center justify-end gap-1.5">
                                  {rateItem.sellChange === 'up' && <TrendingUp className="w-4 h-4 text-red-500" />}
                                  {rateItem.sellChange === 'down' && <TrendingDown className="w-4 h-4 text-emerald-500 animate-pulse" />}
                                  <span className={`text-xs font-mono font-bold py-1 px-2 rounded-lg ${
                                    isMinSell ? "text-blue-700 bg-blue-50 border border-blue-100 font-extrabold shadow-2xs" : "text-slate-700"
                                  }`}>
                                    {rateItem.sell.toFixed(selectedCurrency === 'RUB' || selectedCurrency === 'KZT' ? 3 : 2)}
                                  </span>
                                </div>
                              </td>

                              <td className="py-4 px-6 text-center">
                                <button
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    setSelectedBankIdForModal(item.bankId);
                                  }}
                                  className="text-[10px] text-slate-500 hover:text-blue-600 font-bold bg-slate-50 border border-slate-200 hover:border-blue-300 px-3 py-1.5 rounded-lg transition-all cursor-pointer shadow-xs"
                                >
                                  Справка
                                </button>
                              </td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>

              {/* Fast Inline Som Currency Converter Widget */}
              <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-[28px] p-6 shadow-xs relative overflow-hidden">
                <h3 className="text-sm font-bold text-slate-950 dark:text-white flex items-center gap-1.5 mb-4">
                  <ArrowRightLeft className="w-4 h-4 text-blue-600 dark:text-blue-400" />
                  Экспресс-Калькулятор Конверсии
                </h3>

                <div className="grid grid-cols-1 md:grid-cols-7 items-center gap-4">
                  <div className="md:col-span-3 space-y-1.5">
                    <label className="text-[10px] uppercase font-bold tracking-wider text-slate-500 dark:text-slate-400">Отдаю</label>
                    <div className="flex bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden focus-within:ring-2 focus-within:ring-blue-100/50 focus-within:border-blue-500 transition-all">
                      <input
                        type="number"
                        value={calcAmount}
                        onChange={e => setCalcAmount(e.target.value)}
                        className="flex-1 bg-transparent px-3 py-2.5 text-xs font-bold text-slate-800 dark:text-white placeholder-slate-450 focus:outline-none min-w-0 font-mono"
                      />
                      <select
                        value={calcFrom}
                        onChange={e => setCalcFrom(e.target.value)}
                        className="bg-white dark:bg-slate-900 border-l border-slate-250 dark:border-slate-800 text-xs px-3 font-mono font-extrabold text-slate-700 dark:text-slate-300 hover:text-blue-600 dark:hover:text-blue-400 focus:outline-none cursor-pointer"
                      >
                        <option value="KGS">KGS</option>
                        <option value="USD">USD</option>
                        <option value="EUR">EUR</option>
                        <option value="RUB">RUB</option>
                        <option value="KZT">KZT</option>
                      </select>
                    </div>
                  </div>

                  <div className="md:col-span-1 flex justify-center text-slate-400">
                    <ArrowRightLeft className="w-4 h-4 hover:text-blue-600 dark:hover:text-blue-400 cursor-pointer transition-colors" onClick={() => {
                      const temp = calcFrom;
                      setCalcFrom(calcTo);
                      setCalcTo(temp);
                    }} />
                  </div>

                  <div className="md:col-span-3 space-y-1.5">
                    <label className="text-[10px] uppercase font-bold tracking-wider text-slate-500 dark:text-slate-400">Получаю</label>
                    <div className="flex bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden">
                      <div className="flex-1 px-3 py-2.5 text-xs font-mono font-extrabold text-blue-600 dark:text-blue-400 bg-blue-50/40 dark:bg-blue-950/20 flex items-center">
                        {getConvertedOutput()}
                      </div>
                      <select
                        value={calcTo}
                        onChange={e => setCalcTo(e.target.value)}
                        className="bg-white dark:bg-slate-900 border-l border-slate-250 dark:border-slate-800 text-xs px-3 font-mono font-extrabold text-slate-700 dark:text-slate-300 hover:text-blue-600 dark:hover:text-blue-400 focus:outline-none cursor-pointer"
                      >
                        <option value="KGS">KGS</option>
                        <option value="USD">USD</option>
                        <option value="EUR">EUR</option>
                        <option value="RUB">RUB</option>
                        <option value="KZT">KZT</option>
                      </select>
                    </div>
                  </div>
                </div>

                <div className="bg-slate-550/5 dark:bg-slate-950/40 border border-slate-150/80 dark:border-slate-850 p-3 rounded-xl flex items-center justify-between mt-4">
                  <div className="flex items-center gap-1.5 text-[11px] text-slate-500 dark:text-slate-400">
                    <Info className="w-4 h-4 text-slate-400 dark:text-slate-550" />
                    <span>Расчёт по среднему курсу наличного рынка сома.</span>
                  </div>
                  <span className="text-[10px] text-slate-500 dark:text-slate-400 font-bold font-mono">1 USD = {(rates.find(r => r.bankId === "bakai")?.rates.USD.sell || 89.70)} KGS</span>
                </div>
              </div>
            </div>
          )}

          {activeTab === "banks" && (
            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-[28px] p-6 shadow-xs space-y-5">
              <div>
                <h3 className="text-sm font-bold text-slate-950 dark:text-white flex items-center gap-1.5">
                  <Globe className="w-4 h-4 text-blue-600 dark:text-blue-400" />
                  Все официальные сайты коммерческих банков КР
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 font-medium">Официальные ссылки на порталы банков Кыргызской Республики для проверки процентных ставок кредитования, лизингов, ведения счетов и депозитов физических лиц.</p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {defaultBanksList.map(bank => (
                  <div
                    key={bank.id}
                    className="bg-white dark:bg-slate-900 p-5 border border-slate-200 dark:border-slate-800 rounded-2xl flex flex-col justify-between hover:border-blue-500/50 hover:shadow-xs transition-all group"
                  >
                    <div>
                      <div className="flex justify-between items-start">
                        {renderBankLogo(bank.id, bank.nameRu)}
                        <div className="flex items-center gap-1 bg-[#fef3c7] dark:bg-amber-950/40 text-[#92400e] dark:text-amber-300 px-2 py-0.5 rounded-lg border border-[#fde68a] dark:border-amber-900/60 font-mono text-[10px] font-bold">
                          <span>★</span>
                          <span>{bank.rating.toFixed(1)}</span>
                        </div>
                      </div>

                      <div className="mt-3">
                        <h4 className="text-xs font-bold text-slate-850 dark:text-slate-200 group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors">{bank.nameRu}</h4>
                        <div className="text-[10px] text-slate-400 dark:text-slate-500 mt-1 font-mono transition-all">{bank.website}</div>
                      </div>

                      <div className="space-y-1.5 mt-3 pt-3 border-t border-slate-100 dark:border-slate-800 text-[10px] text-slate-550 dark:text-slate-400">
                        <div className="flex items-center gap-1.5">
                          <Phone className="w-3.5 h-3.5 text-slate-400 dark:text-slate-500" />
                          <span>{bank.phone}</span>
                        </div>
                        <div className="flex items-center gap-1.5">
                          <MapPin className="w-3.5 h-3.5 text-slate-400 dark:text-slate-500" />
                          <span className="truncate">{bank.address}</span>
                        </div>
                      </div>

                      <div className="mt-3 pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between gap-2.5 text-[10px]">
                        {bank.creditUrl && (
                          <a
                            href={bank.creditUrl}
                            target="_blank"
                            rel="noopener noreferrer"
                            onClick={(e) => handleSafeLinkClick(e, bank.creditUrl!, bank.nameRu)}
                            className="flex items-center gap-1 text-slate-500 dark:text-slate-400 hover:text-blue-600 dark:hover:text-blue-400 font-bold transition-colors"
                          >
                            <Scale className="w-3.5 h-3.5 text-blue-500 dark:text-blue-400" />
                            <span>Кредиты банка ↗</span>
                          </a>
                        )}
                        {bank.depositUrl && (
                          <a
                            href={bank.depositUrl}
                            target="_blank"
                            rel="noopener noreferrer"
                            onClick={(e) => handleSafeLinkClick(e, bank.depositUrl!, bank.nameRu)}
                            className="flex items-center gap-1 text-slate-500 dark:text-slate-400 hover:text-emerald-600 dark:hover:text-emerald-400 font-bold transition-colors"
                          >
                            <Percent className="w-3.5 h-3.5 text-emerald-500" />
                            <span>Депозиты банка ↗</span>
                          </a>
                        )}
                      </div>
                    </div>

                    <div className="flex gap-1.5 mt-4 pt-1">
                      <a
                        href={bank.website}
                        target="_blank"
                        rel="noopener noreferrer"
                        onClick={(e) => handleSafeLinkClick(e, bank.website, bank.nameRu)}
                        className="flex-1 py-2 bg-blue-600 hover:bg-blue-700 text-white border border-transparent text-[10px] font-bold rounded-lg text-center transition-all flex items-center justify-center gap-1 cursor-pointer shadow-2xs"
                      >
                        <span>На сайт</span>
                        <ExternalLink className="w-3 h-3" />
                      </a>
                      <button
                        onClick={() => setSelectedBankIdForModal(bank.id)}
                        className="py-2 bg-slate-50 dark:bg-slate-950 hover:bg-slate-100 dark:hover:bg-slate-850 border border-slate-200 dark:border-slate-800 px-2.5 text-[10px] font-bold rounded-lg text-slate-600 dark:text-slate-300 hover:text-slate-800 dark:hover:text-white transition-all cursor-pointer shadow-3xs"
                      >
                        Подробнее
                      </button>
                      <button
                        onClick={() => {
                          setCompareBankIdA(bank.id);
                          setIsCompareModalOpen(true);
                          showToast(`⚖️ Банк ${bank.nameRu} назначен основным для сравнения!`);
                        }}
                        className="py-2 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-755 border border-slate-250 dark:border-slate-750 px-2.5 text-[10px] font-bold rounded-lg text-slate-705 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white transition-all cursor-pointer shadow-3xs flex items-center gap-1 shrink-0"
                      >
                        <Scale className="w-3 h-3 text-blue-600 dark:text-blue-400" />
                        <span>Сравнить</span>
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {activeTab === "loans" && (
            <div className="space-y-6">
              
              {/* Loans Rate Comparison */}
              <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-[28px] p-6 shadow-xs">
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <h3 className="text-sm font-bold text-slate-950 dark:text-white flex items-center gap-1.5">
                      <Scale className="w-4 h-4 text-blue-600 dark:text-blue-400" />
                      Средние процентные ставки кредитования в банках КР
                    </h3>
                    <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5 font-medium">Сравнительный обзор минимальных ставок для физических лиц на потребительские и автокредиты.</p>
                  </div>
                </div>

                <div className="overflow-x-auto">
                  <table className="w-full text-left font-sans text-xs">
                    <thead>
                      <tr className="border-b border-slate-150 dark:border-slate-800 text-[10px] text-slate-500 dark:text-slate-400 uppercase tracking-widest font-bold">
                        <th className="py-3 px-3">Банк</th>
                        <th className="py-3 px-3 text-right">Потребительские сом (KGS)</th>
                        <th className="py-3 px-3 text-right">Валютные ($ USD)</th>
                        <th className="py-3 px-3 text-center">Официальные условия</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                      {defaultBanksList.map(bank => (
                        <tr key={bank.id} className="hover:bg-slate-50/70 dark:hover:bg-slate-800/40">
                          <td className="py-3.5 px-3 font-bold text-slate-850 dark:text-slate-250">{bank.nameRu}</td>
                          <td className="py-3.5 px-3 text-right text-emerald-600 dark:text-emerald-400 font-extrabold font-mono">от {bank.creditMinRateKgs}%</td>
                          <td className="py-3.5 px-3 text-right text-slate-600 dark:text-slate-350 font-bold font-mono">от {bank.creditMinRateUsd}%</td>
                          <td className="py-3.5 px-3 text-center">
                            {bank.creditUrl ? (
                              <a
                                href={bank.creditUrl}
                                target="_blank"
                                rel="noopener noreferrer"
                                onClick={(e) => handleSafeLinkClick(e, bank.creditUrl!, bank.nameRu)}
                                className="text-[10px] text-blue-600 dark:text-blue-400 hover:text-blue-700 dark:hover:text-blue-300 font-bold hover:underline cursor-pointer"
                              >
                                Страница кредитов ↗
                              </a>
                            ) : (
                              <span className="text-[10px] text-slate-350 dark:text-slate-600">—</span>
                            )}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* MBank Specific Credit Products with Expanded Details / Pandas view */}
              <MbankCreditsCard
                onSelectProduct={(prod) => {
                  setLoanRate(prod.rate);
                  setLoanTerm(prod.term);
                  setLoanPrincipal(prod.suggestedAmount);
                  setLoanCurrency("KGS");
                  showToast(`💵 Параметры кредита "${prod.name}" (${prod.rate}%, ${prod.term} мес.) загружены в калькулятор ниже!`);
                }}
                onLinkClick={handleSafeLinkClick}
                isDarkMode={isDarkMode}
              />

              {/* Loans Annuity Loan Calculator */}
              <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-[28px] p-6 shadow-xs relative overflow-hidden">
                <h3 className="text-sm font-bold text-slate-950 dark:text-white flex items-center gap-1.5 mb-1">
                  <Calculator className="w-4 h-4 text-blue-600 dark:text-blue-400" />
                  Кредитный калькулятор КР (Аннуитетный расчёт платежей)
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400 mb-5 font-medium">Рассчитайте ежемесячные отчисления по кредиту в сомах или долларах по формуле аннуитета национальной системы банковского учёта Кыргызской Республики.</p>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
                  <div className="space-y-4">
                    <div className="space-y-1.5">
                      <label className="text-[10px] uppercase font-bold tracking-wider text-slate-500 dark:text-slate-400">Сумма кредита</label>
                      <div className="flex bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden focus-within:ring-2 focus-within:ring-blue-100/55 focus-within:border-blue-500 transition-all">
                        <input
                          type="number"
                          value={loanPrincipal}
                          onChange={e => setLoanPrincipal(Math.max(0, parseInt(e.target.value) || 0))}
                          className="flex-1 bg-transparent px-3 py-2.5 text-xs font-bold font-mono focus:outline-none text-slate-800 dark:text-white"
                        />
                        <select
                          value={loanCurrency}
                          onChange={e => setLoanCurrency(e.target.value as "KGS" | "USD")}
                          className="bg-white dark:bg-slate-900 text-xs px-2.5 font-mono font-bold text-slate-700 dark:text-slate-300 border-l border-slate-200 dark:border-slate-800 hover:text-blue-600 cursor-pointer"
                        >
                          <option value="KGS">KGS</option>
                          <option value="USD">USD</option>
                        </select>
                      </div>
                    </div>

                    <div className="space-y-1.5">
                      <div className="flex justify-between items-center text-[11px]">
                        <span className="text-slate-500 dark:text-slate-400 font-bold">Срок займа</span>
                        <span className="text-blue-600 dark:text-blue-400 font-extrabold">{loanTerm} месяцев</span>
                      </div>
                      <input
                        type="range"
                        min="3"
                        max="120"
                        value={loanTerm}
                        onChange={e => setLoanTerm(parseInt(e.target.value))}
                        className="w-full h-1 bg-slate-200 dark:bg-slate-800 rounded-lg appearance-none cursor-pointer accent-blue-600"
                      />
                    </div>

                    <div className="space-y-1.5">
                      <div className="flex justify-between items-center text-[11px]">
                        <span className="text-slate-500 dark:text-slate-400 font-bold">Процентная ставка годовых</span>
                        <span className="text-blue-600 dark:text-blue-400 font-extrabold">{loanRate}%</span>
                      </div>
                      <input
                        type="range"
                        min="5"
                        max="36"
                        value={loanRate}
                        onChange={e => setLoanRate(parseFloat(e.target.value))}
                        className="w-full h-1 bg-slate-200 dark:bg-slate-800 rounded-lg appearance-none cursor-pointer accent-blue-600"
                      />
                    </div>
                  </div>

                  <div className="md:col-span-2 bg-slate-50 dark:bg-slate-950 p-5 rounded-2xl border border-slate-150 dark:border-slate-800 flex flex-col justify-between shadow-3xs">
                    <div className="grid grid-cols-2 gap-4 text-center">
                      <div className="bg-white dark:bg-slate-900 p-3 rounded-xl border border-slate-200 dark:border-slate-850 shadow-ws animate-fade-in">
                        <span className="text-[9px] text-slate-400 dark:text-slate-500 font-bold uppercase tracking-wider block">Ежемесячный платёж</span>
                        <span className="text-sm font-mono font-extrabold text-blue-600 dark:text-blue-400 mt-1 block">
                          {loanResults.monthlyPayment.toLocaleString("ru-RU", { maximumFractionDigits: 1 })} {loanCurrency === "KGS" ? "сом" : "$"}
                        </span>
                      </div>
                      <div className="bg-white dark:bg-slate-900 p-3 rounded-xl border border-slate-200 dark:border-slate-850 shadow-ws animate-fade-in">
                        <span className="text-[9px] text-slate-400 dark:text-slate-500 font-bold uppercase tracking-wider block">Переплата по процентам</span>
                        <span className="text-sm font-mono font-extrabold text-[#e11d48] dark:text-red-400 mt-1 block">
                          {loanResults.totalInterest.toLocaleString("ru-RU", { maximumFractionDigits: 1 })} {loanCurrency === "KGS" ? "сом" : "$"}
                        </span>
                      </div>
                    </div>

                    <div className="mt-4 space-y-2 border-t border-slate-200/80 dark:border-slate-800 pt-4 text-[11px] text-slate-500 dark:text-slate-400 font-semibold">
                      <div className="flex justify-between">
                        <span>Заплатите всего долга + процентов:</span>
                        <strong className="text-slate-800 dark:text-slate-200">{loanResults.totalPaid.toLocaleString("ru-RU", { maximumFractionDigits: 0 })} {loanCurrency === "KGS" ? "сом" : "$"}</strong>
                      </div>
                      <div className="flex justify-between">
                        <span>Ориентировочно лучшее предложение в сомах:</span>
                        <strong className="text-emerald-600 dark:text-emerald-400">Айыл Банк (от 12.0%)</strong>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeTab === "deposits" && (
            <div className="space-y-6">
              
              {/* Deposits Rate Comparison */}
              <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-[28px] p-6 shadow-xs">
                <div>
                  <h3 className="text-sm font-bold text-slate-950 dark:text-white flex items-center gap-1.5">
                    <Percent className="w-4 h-4 text-blue-600 dark:text-blue-400" />
                    Максимальные депозитные ставки коммерческих вкладов в КР
                  </h3>
                  <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5 font-medium">Сравнительный обзор maximal доходности по срочным вкладам для накоплений граждан КР.</p>
                </div>

                <div className="overflow-x-auto mt-4">
                  <table className="w-full text-left font-sans text-xs">
                    <thead>
                      <tr className="border-b border-slate-150 dark:border-slate-800 text-[10px] text-slate-500 dark:text-slate-400 uppercase tracking-widest font-bold">
                        <th className="py-3 px-3">Копилка Банка</th>
                        <th className="py-3 px-3 text-right">Национальная ставка (KGS)</th>
                        <th className="py-3 px-3 text-right">Валютная ($ USD)</th>
                        <th className="py-3 px-3 text-center">Договор накопления</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                      {defaultBanksList.map(bank => (
                        <tr key={bank.id} className="hover:bg-slate-50/70 dark:hover:bg-slate-800/40">
                          <td className="py-3.5 px-3 font-bold text-slate-850 dark:text-slate-250">{bank.nameRu}</td>
                          <td className="py-3.5 px-3 text-right text-emerald-600 dark:text-emerald-400 font-extrabold font-mono">до {bank.depositMaxRateKgs}%</td>
                          <td className="py-3.5 px-3 text-right text-slate-600 dark:text-slate-350 font-bold font-mono">до {bank.depositMaxRateUsd}%</td>
                          <td className="py-3.5 px-3 text-center">
                            {bank.depositUrl ? (
                              <a
                                href={bank.depositUrl}
                                target="_blank"
                                rel="noopener noreferrer"
                                onClick={(e) => handleSafeLinkClick(e, bank.depositUrl!, bank.nameRu)}
                                className="text-[10px] text-blue-600 dark:text-blue-400 hover:text-blue-700 dark:hover:text-blue-300 font-bold hover:underline cursor-pointer"
                              >
                                Страница вкладов ↗
                              </a>
                            ) : (
                              <span className="text-[10px] text-slate-350 dark:text-slate-600">—</span>
                            )}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* MBank Specific Deposit Products */}
              <MbankDepositsCard
                onSelectProduct={(prod) => {
                  setDepCurrency(prod.currency);
                  setDepRate(prod.rate);
                  setDepTerm(prod.term);
                  if (prod.currency === "USD") {
                    setDepPrincipal(2000);
                  } else {
                    setDepPrincipal(100000);
                  }
                  showToast(`💰 Параметры "${prod.name}" (${prod.rate}%, ${prod.term} мес.) загружены в калькулятор ниже!`);
                }}
                onLinkClick={handleSafeLinkClick}
                isDarkMode={isDarkMode}
              />

              {/* Deposit Predictor Calculator */}
              <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-[28px] p-6 shadow-xs relative overflow-hidden">
                <h3 className="text-sm font-bold text-slate-950 dark:text-white flex items-center gap-1.5 mb-1">
                  <PiggyBank className="w-4 h-4 text-blue-600 dark:text-blue-400" />
                  Депозитный Калькулятор Доходности Вкладов
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400 mb-5 font-medium">Рассчитайте ориентировочный прирост и чистый советуемый остаток по депозиту в Кыргызстане.</p>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
                  <div className="space-y-4">
                    <div className="space-y-1.5">
                      <label className="text-[10px] uppercase font-bold tracking-wider text-slate-500 dark:text-slate-400">Начальная сумма вклада</label>
                      <div className="flex bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden focus-within:ring-2 focus-within:ring-blue-100/55 focus-within:border-blue-500 transition-all font-sans font-bold">
                        <input
                          type="number"
                          value={depPrincipal}
                          onChange={e => setDepPrincipal(Math.max(0, parseInt(e.target.value) || 0))}
                          className="flex-1 bg-transparent px-3 py-2.5 text-xs font-bold font-mono focus:outline-none text-slate-800 dark:text-white"
                        />
                        <select
                          value={depCurrency}
                          onChange={e => setDepCurrency(e.target.value as "KGS" | "USD")}
                          className="bg-white dark:bg-slate-900 text-xs px-2.5 font-mono font-bold text-slate-700 dark:text-slate-300 border-l border-slate-200 dark:border-slate-800 hover:text-blue-600 cursor-pointer"
                        >
                          <option value="KGS">KGS</option>
                          <option value="USD">USD</option>
                        </select>
                      </div>
                    </div>

                    <div className="space-y-1.5">
                      <div className="flex justify-between items-center text-[11px]">
                        <span className="text-slate-500 dark:text-slate-400 font-bold font-sans">Срок размещения вклада</span>
                        <span className="text-blue-600 dark:text-blue-400 font-extrabold font-sans">{depTerm} месяцев</span>
                      </div>
                      <input
                        type="range"
                        min="1"
                        max="36"
                        value={depTerm}
                        onChange={e => setDepTerm(parseInt(e.target.value))}
                        className="w-full h-1 bg-slate-200 dark:bg-slate-800 rounded-lg appearance-none cursor-pointer accent-blue-600"
                      />
                    </div>

                    <div className="space-y-1.5">
                      <div className="flex justify-between items-center text-[11px]">
                        <span className="text-slate-500 dark:text-slate-400 font-bold font-sans">Процентная годовая ставка</span>
                        <span className="text-blue-600 dark:text-blue-400 font-extrabold font-sans">{depRate}%</span>
                      </div>
                      <input
                        type="range"
                        min="2"
                        max="16"
                        step="0.5"
                        value={depRate}
                        onChange={e => setDepRate(parseFloat(e.target.value))}
                        className="w-full h-1 bg-slate-200 dark:bg-slate-800 rounded-lg appearance-none cursor-pointer accent-blue-600"
                      />
                    </div>
                  </div>

                  <div className="md:col-span-2 bg-slate-50 dark:bg-slate-950 p-5 rounded-2xl border border-slate-150 dark:border-slate-800 flex flex-col justify-between shadow-3xs">
                    <div className="grid grid-cols-2 gap-4 text-center">
                      <div className="bg-white dark:bg-slate-900 p-3 rounded-xl border border-slate-200 dark:border-slate-850 shadow-ws font-sans">
                        <span className="text-[9px] text-slate-400 dark:text-slate-500 font-sans font-bold uppercase tracking-wider block">Начисленные проценты</span>
                        <span className="text-sm font-sans font-extrabold text-emerald-600 dark:text-emerald-400 mt-1 block">
                          {depositResults.earnedInterest.toLocaleString("ru-RU", { maximumFractionDigits: 1 })} {depCurrency === "KGS" ? "сом" : "$"}
                        </span>
                      </div>
                      <div className="bg-white dark:bg-slate-900 p-3 rounded-xl border border-slate-200 dark:border-slate-850 shadow-ws font-sans">
                        <span className="text-[9px] text-slate-400 dark:text-slate-500 font-sans font-bold uppercase tracking-wider block">Итоговая сумма выплаты</span>
                        <span className="text-sm font-sans font-extrabold text-blue-600 dark:text-blue-400 mt-1 block">
                          {depositResults.netPayout.toLocaleString("ru-RU", { maximumFractionDigits: 1 })} {depCurrency === "KGS" ? "сом" : "$"}
                        </span>
                      </div>
                    </div>

                    <div className="mt-4 space-y-2 border-t border-slate-200/80 dark:border-slate-800 pt-4 text-[11px] text-slate-500 dark:text-slate-400 font-semibold font-sans">
                      <div className="flex justify-between font-sans">
                        <span>Налог на проценты по вкладам (КР 5%):</span>
                        <strong className="text-rose-650 dark:text-rose-400">-{depositResults.taxValue.toLocaleString("ru-RU", { maximumFractionDigits: 0 })} {depCurrency === "KGS" ? "сом" : "$"}</strong>
                      </div>
                      <div className="flex justify-between font-sans">
                        <span>Лучшее застрахованное по сомам:</span>
                        <strong className="text-emerald-600 dark:text-emerald-400 font-bold font-sans">Элдик Банк (до 14.0%)</strong>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}
        </section>

        {/* Right Side panel: SVG Line Charts, Chat Assistant and metadata */}
        <section className="lg:col-span-4 space-y-6">
          
          {/* SVG Rates Chart Widget */}
          {renderInteractiveChart()}

          {/* AI Advisor Chat Bot Console */}
          <div className="bg-white border border-slate-200 rounded-[28px] overflow-hidden flex flex-col h-[400px] shadow-xs relative">
            <div className="p-4 bg-slate-50 border-b border-slate-200 flex items-center gap-3.5">
              <div className="w-9 h-9 rounded-xl bg-blue-600 p-0.5 flex items-center justify-center">
                <Sparkles className="w-4 h-4 text-white" />
              </div>
              <div>
                <h3 className="text-xs font-bold text-slate-900 flex items-center gap-1.5">
                  Финансовый ИИ-Помощник
                </h3>
                <span className="text-[10px] text-slate-500 flex items-center gap-1 font-bold">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                  Модель: gemini-2.5-flash + Поиск Google
                </span>
              </div>
            </div>

            {/* Chat Body messages stream */}
            <div className="flex-1 overflow-y-auto p-4 space-y-3 scrollbar-none bg-white">
              {messages.map((m, idx) => (
                <div key={idx} className={`flex ${m.sender === "user" ? "justify-end" : "justify-start"}`}>
                  <div className={`p-3 rounded-2xl max-w-[85%] text-xs leading-relaxed space-y-1.5 ${
                    m.sender === "user"
                      ? "bg-blue-600 text-white rounded-tr-none font-bold"
                      : "bg-slate-50 border border-slate-200 text-slate-800 rounded-tl-none font-medium"
                  }`}>
                    <p className="whitespace-pre-line">{m.text}</p>
                    
                    {/* Sources grounded on Search if returned */}
                    {m.groundingSources && m.groundingSources.length > 0 && (
                      <div className="pt-2 border-t border-slate-200 mt-1.5">
                        <span className="text-[9px] text-slate-400 block uppercase font-bold tracking-wider">Проверенные источники:</span>
                        <div className="flex flex-wrap gap-1.5 mt-1">
                          {m.groundingSources.slice(0, 3).map((source, sIdx) => (
                            <a
                              key={sIdx}
                              href={source.uri}
                              target="_blank"
                              rel="noreferrer"
                              className="text-[9px] bg-white text-blue-600 hover:text-blue-700 px-1.5 py-0.5 rounded border border-slate-200 flex items-center gap-0.5 font-bold"
                            >
                              <Globe className="w-2.5 h-2.5" />
                              <span className="truncate max-w-[100px]">{source.title}</span>
                            </a>
                          ))}
                        </div>
                      </div>
                    )}
                    
                    <span className={`text-[8px] font-mono block text-right mt-1 ${m.sender === 'user' ? 'text-blue-200' : 'text-slate-400'}`}>
                      {m.timestamp}
                    </span>
                  </div>
                </div>
              ))}
              {isSendingToAI && (
                <div className="flex justify-start">
                  <div className="bg-slate-55 border border-slate-200 px-4 py-3 rounded-2xl rounded-tl-none flex items-center gap-2">
                    <span className="w-1.5 h-1.5 rounded-full bg-blue-600 animate-bounce" />
                    <span className="w-1.5 h-1.5 rounded-full bg-blue-600 animate-bounce [animation-delay:0.2s]" />
                    <span className="w-1.5 h-1.5 rounded-full bg-blue-600 animate-bounce [animation-delay:0.4s]" />
                  </div>
                </div>
              )}
              <div ref={chatBottomRef} />
            </div>

            {/* Quick pre-filled prompt suggestions */}
            <div className="p-2 border-t border-slate-150 bg-slate-50 flex gap-1.5 overflow-x-auto whitespace-nowrap">
              <button
                onClick={() => handleSendMessage("Предоставь краткую сводку финансовых новостей по Кыргызстану, влияющих на курсы валют")}
                className="text-[10px] bg-amber-500 hover:bg-amber-650 border border-amber-600 px-2.5 py-1 rounded-lg text-white font-bold transition-all focus:outline-none shadow-xs flex items-center gap-1 cursor-pointer"
              >
                <Sparkles className="w-3 h-3 text-white" /> Финансовые новости КР 📰
              </button>
              <button
                onClick={() => handleSendMessage("Где выгоднее купить доллар в Бишкеке?")}
                className="text-[10px] bg-white hover:bg-slate-50 border border-slate-200 px-2.5 py-1 rounded-lg text-slate-600 font-bold transition-all focus:outline-none"
              >
                Лучший курс долларов 💵
              </button>
              <button
                onClick={() => handleSendMessage("В каком банке высокий процент по депозитам в сомах?")}
                className="text-[10px] bg-white hover:bg-slate-50 border border-slate-200 px-2.5 py-1 rounded-lg text-slate-600 font-bold transition-all focus:outline-none"
              >
                Лучший вклад в сомах 📈
              </button>
              <button
                onClick={() => handleSendMessage("Каковы ставки на кредиты физическим лицам в КР?")}
                className="text-[10px] bg-white hover:bg-slate-50 border border-slate-200 px-2.5 py-1 rounded-lg text-slate-600 font-bold transition-all focus:outline-none"
              >
                Ставки на кредиты КР 🏦
              </button>
            </div>

            {/* Input Bar area */}
            <div className="p-3 bg-slate-50 border-t border-slate-200 flex items-center gap-2">
              <input
                type="text"
                placeholder="Задать вопрос ИИ по курсам или расчету..."
                value={userInput}
                onChange={e => setUserInput(e.target.value)}
                onKeyDown={e => e.key === "Enter" && handleSendMessage()}
                className="flex-1 bg-white border border-slate-200 focus:border-blue-500 font-sans text-xs focus:outline-none placeholder-slate-400 px-3 py-2.5 rounded-xl text-slate-800 font-bold"
              />
              <button
                onClick={() => handleSendMessage()}
                className="bg-blue-600 hover:bg-blue-700 text-white p-2.5 rounded-xl transition-all cursor-pointer flex items-center justify-center"
              >
                <Send className="w-4 h-4" />
              </button>
            </div>
          </div>
        </section>
      </main>

      {/* Comparison Modal side-by-side analysis */}
      {isCompareModalOpen && (() => {
        const compareBankA = defaultBanksList.find(b => b.id === compareBankIdA) || defaultBanksList[0];
        const compareBankB = defaultBanksList.find(b => b.id === compareBankIdB) || defaultBanksList[1];
        const compareRateA = rates.find(r => r.bankId === compareBankIdA);
        const compareRateB = rates.find(r => r.bankId === compareBankIdB);

        const calculateLoanForBank = (p: number, r: number, t: number) => {
          const monthlyRate = (r / 100) / 12;
          if (monthlyRate === 0) {
            return { monthly: p / t, totalOver: 0 };
          }
          const monthly = p * (monthlyRate * Math.pow(1 + monthlyRate, t)) / (Math.pow(1 + monthlyRate, t) - 1);
          const totalPaid = monthly * t;
          return { monthly, totalOver: Math.max(0, totalPaid - p) };
        };

        const calculateDepositForBank = (p: number, r: number, t: number) => {
          const earned = p * (r / 100) * (t / 12);
          const tax = earned * 0.05;
          return { earned: Math.max(0, earned - tax) };
        };

        return (
          <div className="fixed inset-0 bg-slate-950/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-in fade-in duration-200">
            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-[24px] max-w-4xl w-full max-h-[90vh] overflow-hidden shadow-2xl relative flex flex-col animate-in fade-in zoom-in-95 duration-250">
              {/* Header */}
              <div className="p-6 border-b border-slate-150 dark:border-slate-800 flex justify-between items-center bg-slate-50 dark:bg-slate-950/40">
                <div className="flex items-center gap-2">
                  <Scale className="w-5 h-5 text-blue-600 dark:text-blue-400" />
                  <div>
                    <h3 className="text-sm font-extrabold text-slate-900 dark:text-white">Сопоставление условий: {compareBankA.nameRu} ⚖️ {compareBankB.nameRu}</h3>
                    <p className="text-[10px] text-slate-500 font-bold">Сравнительный финансовый анализ коммерческих предложений на {new Date().toLocaleDateString("ru-RU")}</p>
                  </div>
                </div>
                <button
                  onClick={() => setIsCompareModalOpen(false)}
                  className="text-slate-400 dark:text-slate-500 hover:text-slate-800 dark:hover:text-white transition-colors p-1 cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Scrollable Area */}
              <div className="p-6 overflow-y-auto space-y-6 flex-1 font-sans text-xs">
                
                {/* Top Bank Identity Match */}
                <div className="grid grid-cols-2 gap-4">
                  {/* Bank A Card */}
                  <div className="bg-slate-50 dark:bg-[#141f3e] p-5 rounded-2xl border border-slate-200 dark:border-slate-800 flex flex-col items-center text-center space-y-2.5">
                    <div className="flex items-center justify-center">
                      {renderBankLogo(compareBankA.id, compareBankA.nameRu)}
                    </div>
                    <h4 className="text-xs font-bold text-slate-850 dark:text-white">{compareBankA.nameRu}</h4>
                    <div className="flex items-center gap-1 bg-[#fef3c7] dark:bg-amber-950/40 text-[#92400e] dark:text-amber-300 px-2.5 py-0.5 rounded-lg border border-[#fde68a] dark:border-amber-900/60 font-mono text-[10px] font-bold">
                      <span>★</span>
                      <span>{compareBankA.rating.toFixed(1)}</span>
                    </div>
                    <div className="text-[10px] text-slate-400 dark:text-slate-500">{compareBankA.phone}</div>
                  </div>

                  {/* Bank B Card */}
                  <div className="bg-slate-50 dark:bg-[#141f3e] p-5 rounded-2xl border border-slate-200 dark:border-slate-800 flex flex-col items-center text-center space-y-2.5">
                    <div className="flex items-center justify-center">
                      {renderBankLogo(compareBankB.id, compareBankB.nameRu)}
                    </div>
                    <h4 className="text-xs font-bold text-slate-850 dark:text-white">{compareBankB.nameRu}</h4>
                    <div className="flex items-center gap-1 bg-[#fef3c7] dark:bg-amber-950/40 text-[#92400e] dark:text-amber-300 px-2.5 py-0.5 rounded-lg border border-[#fde68a] dark:border-amber-900/60 font-mono text-[10px] font-bold">
                      <span>★</span>
                      <span>{compareBankB.rating.toFixed(1)}</span>
                    </div>
                    <div className="text-[10px] text-slate-400 dark:text-slate-500">{compareBankB.phone}</div>
                  </div>
                </div>

                {/* SECTION: Exchange Rates */}
                <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl overflow-hidden shadow-3xs">
                  <div className="p-3 bg-slate-50 dark:bg-slate-950/60 border-b border-slate-150 dark:border-slate-800 flex items-center justify-between font-bold">
                    <span className="text-[10px] uppercase tracking-wider text-slate-505 dark:text-slate-300">Курсы обмена наличных валют (в KGS)</span>
                    <span className="text-[10px] text-slate-405 dark:text-slate-400 font-medium">Ставки покупки и продажи</span>
                  </div>
                  
                  <div className="p-4 space-y-3">
                    {(["USD", "EUR", "RUB", "KZT"] as const).map(curr => {
                      const rateA = compareRateA?.rates[curr];
                      const rateB = compareRateB?.rates[curr];
                      if (!rateA || !rateB) return null;

                      // Compute best buy (highest is best to sell to)
                      const isABestBuy = rateA.buy >= rateB.buy;
                      const isBBestBuy = rateB.buy >= rateA.buy;

                      // Compute best sell (lowest is best to buy from)
                      const isABestSell = rateA.sell <= rateB.sell;
                      const isBBestSell = rateB.sell <= rateA.sell;

                      return (
                        <div key={curr} className="grid grid-cols-12 gap-2 items-center py-2 border-b border-slate-100 last:border-b-0 dark:border-slate-800/60">
                          {/* Currency Tag */}
                          <div className="col-span-2 flex items-center gap-1.5">
                            <span className="font-mono text-slate-400 dark:text-slate-500 font-extrabold">{currencyDescriptions[curr].symbol}</span>
                            <span className="font-bold text-slate-800 dark:text-white">{curr}</span>
                          </div>

                          {/* Bank A Exchange Rate Info */}
                          <div className="col-span-5 grid grid-cols-2 gap-1 px-2 border-r border-slate-150 dark:border-slate-800">
                            <div className={`p-1.5 rounded-lg text-center ${isABestBuy && rateA.buy !== rateB.buy ? 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 font-extrabold border border-emerald-500/20' : 'bg-slate-50 dark:bg-slate-950 text-slate-600 dark:text-slate-300'}`}>
                              <div className="text-[8px] text-slate-400 dark:text-slate-500 font-bold uppercase">Покупка</div>
                              <span className="font-mono">{rateA.buy.toFixed(curr === 'RUB' || curr === 'KZT' ? 3 : 2)}</span>
                            </div>
                            <div className={`p-1.5 rounded-lg text-center ${isABestSell && rateA.sell !== rateB.sell ? 'bg-blue-500/10 text-blue-600 dark:text-blue-400 font-extrabold border border-blue-500/20' : 'bg-slate-50 dark:bg-slate-950 text-slate-600 dark:text-slate-300'}`}>
                              <div className="text-[8px] text-slate-400 dark:text-slate-500 font-bold uppercase">Продажа</div>
                              <span className="font-mono">{rateA.sell.toFixed(curr === 'RUB' || curr === 'KZT' ? 3 : 2)}</span>
                            </div>
                          </div>

                          {/* Bank B Exchange Rate Info */}
                          <div className="col-span-5 grid grid-cols-2 gap-1 px-2">
                            <div className={`p-1.5 rounded-lg text-center ${isBBestBuy && rateA.buy !== rateB.buy ? 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 font-extrabold border border-emerald-500/20' : 'bg-slate-50 dark:bg-slate-950 text-slate-600 dark:text-slate-300'}`}>
                              <div className="text-[8px] text-slate-400 dark:text-slate-500 font-bold uppercase">Покупка</div>
                              <span className="font-mono">{rateB.buy.toFixed(curr === 'RUB' || curr === 'KZT' ? 3 : 2)}</span>
                            </div>
                            <div className={`p-1.5 rounded-lg text-center ${isBBestSell && rateA.sell !== rateB.sell ? 'bg-blue-500/10 text-blue-600 dark:text-blue-400 font-extrabold border border-blue-500/20' : 'bg-slate-50 dark:bg-slate-950 text-slate-600 dark:text-slate-300'}`}>
                              <div className="text-[8px] text-slate-400 dark:text-slate-500 font-bold uppercase">Продажа</div>
                              <span className="font-mono">{rateB.sell.toFixed(curr === 'RUB' || curr === 'KZT' ? 3 : 2)}</span>
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>

                {/* SECTION: Credits */}
                <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl overflow-hidden shadow-3xs">
                  <div className="p-3 bg-slate-50 dark:bg-slate-950/60 border-b border-slate-150 dark:border-slate-800 flex items-center justify-between font-bold text-blue-700 dark:text-blue-400">
                    <span className="text-[10px] uppercase tracking-wider flex items-center gap-1.5">
                      <Scale className="w-3.5 h-3.5 animate-pulse" />
                      Кредиты: Процентные ставки и симуляция платежей
                    </span>
                    <span className="text-[10px] font-bold">Базовый обзор условий %</span>
                  </div>
                  
                  <div className="p-4 space-y-4">
                    {/* Min rates row comparison */}
                    <div className="grid grid-cols-12 gap-2 text-center pb-3 border-b border-slate-105/60 dark:border-slate-800">
                      <div className="col-span-2 text-left font-bold text-slate-500 dark:text-slate-400 flex items-center">Ставки (%)</div>
                      <div className="col-span-5 bg-slate-50 dark:bg-slate-955/40 p-2.5 rounded-xl border border-slate-200/50 dark:border-slate-800/60">
                        <div className="text-slate-400 font-extrabold uppercase text-[8px]">KGS сомы</div>
                        <div className="font-extrabold text-slate-850 dark:text-white mt-0.5">от {compareBankA.creditMinRateKgs}%</div>
                        <div className="text-slate-400 font-extrabold uppercase text-[8px] mt-2">USD валюта</div>
                        <div className="font-extrabold text-slate-850 dark:text-white mt-0.5">от {compareBankA.creditMinRateUsd}%</div>
                      </div>
                      <div className="col-span-5 bg-slate-50 dark:bg-slate-955/40 p-2.5 rounded-xl border border-slate-200/50 dark:border-slate-800/60">
                        <div className="text-slate-400 font-extrabold uppercase text-[8px]">KGS сомы</div>
                        <div className="font-extrabold text-slate-850 dark:text-white mt-0.5">от {compareBankB.creditMinRateKgs}%</div>
                        <div className="text-slate-400 font-extrabold uppercase text-[8px] mt-2">USD валюта</div>
                        <div className="font-extrabold text-slate-850 dark:text-white mt-0.5">от {compareBankB.creditMinRateUsd}%</div>
                      </div>
                    </div>

                    {/* Calculator Simulation Preview */}
                    <div className="bg-blue-50/40 dark:bg-[#11182d] p-4.5 rounded-2xl space-y-3 border border-blue-100/50 dark:border-slate-850">
                      <div className="flex justify-between items-center text-[10px] text-slate-500 uppercase tracking-widest font-bold">
                        <span>Моделирование кредита</span>
                        <span className="text-blue-600 dark:text-blue-400 font-mono">Сумма: 300 000 KGS / Срок: 12 мес</span>
                      </div>

                      <div className="grid grid-cols-2 gap-4">
                        {/* Bank A Loan Comp */}
                        {(() => {
                          const sim = calculateLoanForBank(300000, compareBankA.creditMinRateKgs, 12);
                          return (
                            <div className="space-y-1.5 border-r border-slate-200 dark:border-slate-800 pr-2">
                              <span className="text-[10px] text-slate-450 font-bold dark:text-slate-400">В {compareBankA.nameRu}:</span>
                              <div className="flex items-baseline gap-1 mt-1">
                                <span className="text-xs font-mono font-black text-slate-900 dark:text-white">{sim.monthly.toLocaleString("ru-RU", { maximumFractionDigits: 0 })} KGS</span>
                                <span className="text-[9px] text-slate-400">/ мес.</span>
                              </div>
                              <div className="text-[9px] text-slate-400">Общая переплата за год: <strong className="font-mono text-red-650 dark:text-red-400 font-extrabold">{sim.totalOver.toLocaleString("ru-RU", { maximumFractionDigits: 0 })} KGS</strong></div>
                            </div>
                          );
                        })()}

                        {/* Bank B Loan Comp */}
                        {(() => {
                          const sim = calculateLoanForBank(300000, compareBankB.creditMinRateKgs, 12);
                          return (
                            <div className="space-y-1.5 pl-2">
                              <span className="text-[10px] text-slate-450 font-bold dark:text-slate-400">В {compareBankB.nameRu}:</span>
                              <div className="flex items-baseline gap-1 mt-1">
                                <span className="text-xs font-mono font-black text-slate-900 dark:text-white">{sim.monthly.toLocaleString("ru-RU", { maximumFractionDigits: 0 })} KGS</span>
                                <span className="text-[9px] text-slate-400">/ мес.</span>
                              </div>
                              <div className="text-[9px] text-slate-400">Общая переплата за год: <strong className="font-mono text-red-650 dark:text-red-400 font-extrabold">{sim.totalOver.toLocaleString("ru-RU", { maximumFractionDigits: 0 })} KGS</strong></div>
                            </div>
                          );
                        })()}
                      </div>
                    </div>
                  </div>
                </div>

                {/* SECTION: Deposits */}
                <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl overflow-hidden shadow-3xs">
                  <div className="p-3 bg-slate-50 dark:bg-slate-950/60 border-b border-slate-150 dark:border-slate-800 flex items-center justify-between font-bold text-emerald-700 dark:text-emerald-400">
                    <span className="text-[10px] uppercase tracking-wider flex items-center gap-1.5">
                      <PiggyBank className="w-3.5 h-3.5" />
                      Депозиты: Процентные ставки и пассивный доход
                    </span>
                    <span className="text-[10px] font-bold">Максимальная доходность вкладов %</span>
                  </div>
                  
                  <div className="p-4 space-y-4">
                    {/* Min rates row comparison */}
                    <div className="grid grid-cols-12 gap-2 text-center pb-3 border-b border-slate-105/60 dark:border-slate-800">
                      <div className="col-span-2 text-left font-bold text-slate-500 dark:text-slate-400 flex items-center font-sans">Ставки (%)</div>
                      <div className="col-span-5 bg-slate-50 dark:bg-slate-955/40 p-2.5 rounded-xl border border-slate-200/50 dark:border-slate-800/60">
                        <div className="text-slate-400 font-extrabold uppercase text-[8px]">KGS сомы</div>
                        <div className="font-extrabold text-slate-850 dark:text-white mt-0.5">до {compareBankA.depositMaxRateKgs}% годовых</div>
                        <div className="text-slate-400 font-extrabold uppercase text-[8px] mt-2">USD валюта</div>
                        <div className="font-extrabold text-slate-850 dark:text-white mt-0.5">до {compareBankA.depositMaxRateUsd}% годовых</div>
                      </div>
                      <div className="col-span-5 bg-slate-50 dark:bg-slate-955/40 p-2.5 rounded-xl border border-slate-200/50 dark:border-slate-800/60">
                        <div className="text-slate-400 font-extrabold uppercase text-[8px]">KGS сомы</div>
                        <div className="font-extrabold text-slate-850 dark:text-white mt-0.5">до {compareBankB.depositMaxRateKgs}% годовых</div>
                        <div className="text-slate-400 font-extrabold uppercase text-[8px] mt-2">USD валюта</div>
                        <div className="font-extrabold text-slate-850 dark:text-white mt-0.5">до {compareBankB.depositMaxRateUsd}% годовых</div>
                      </div>
                    </div>

                    {/* Calculator Simulation Preview */}
                    <div className="bg-emerald-50/40 dark:bg-[#111c2a] p-4.5 rounded-2xl space-y-3 border border-emerald-100/50 dark:border-slate-850">
                      <div className="flex justify-between items-center text-[10px] text-slate-500 uppercase tracking-widest font-bold">
                        <span>Моделирование доходности вклада</span>
                        <span className="text-emerald-600 dark:text-emerald-400 font-mono">Депозит: 100 000 KGS / Срок: 12 мес</span>
                      </div>

                      <div className="grid grid-cols-2 gap-4">
                        {/* Bank A Deposit profit */}
                        {(() => {
                          const sim = calculateDepositForBank(100000, compareBankA.depositMaxRateKgs, 12);
                          return (
                            <div className="space-y-1.5 border-r border-slate-200 dark:border-slate-800 pr-2">
                              <span className="text-[10px] text-slate-450 font-bold dark:text-slate-400">Чистая прибыль {compareBankA.nameRu}:</span>
                              <div className="flex items-baseline gap-1 mt-1">
                                <span className="text-xs font-mono font-black text-emerald-600 dark:text-emerald-400">+{sim.earned.toLocaleString("ru-RU", { maximumFractionDigits: 0 })} KGS</span>
                              </div>
                              <div className="text-[8px] text-slate-400 mt-1 block tracking-tight leading-none">*с учётом вычета обязательного КР налога 5%</div>
                            </div>
                          );
                        })()}

                        {/* Bank B Deposit profit */}
                        {(() => {
                          const sim = calculateDepositForBank(100000, compareBankB.depositMaxRateKgs, 12);
                          return (
                            <div className="space-y-1.5 pl-2">
                              <span className="text-[10px] text-slate-450 font-bold dark:text-slate-400">Чистая прибыль {compareBankB.nameRu}:</span>
                              <div className="flex items-baseline gap-1 mt-1">
                                <span className="text-xs font-mono font-black text-emerald-600 dark:text-emerald-400">+{sim.earned.toLocaleString("ru-RU", { maximumFractionDigits: 0 })} KGS</span>
                              </div>
                              <div className="text-[8px] text-slate-400 mt-1 block tracking-tight leading-none">*с учётом вычета обязательного КР налога 5%</div>
                            </div>
                          );
                        })()}
                      </div>
                    </div>
                  </div>
                </div>

              </div>

              {/* Footer buttons */}
              <div className="p-4 bg-slate-50 dark:bg-slate-950 border-t border-slate-200 dark:border-slate-800 flex justify-end gap-3 rounded-b-[24px]">
                <button
                  onClick={() => setIsCompareModalOpen(false)}
                  className="bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs px-6 py-2.5 rounded-xl transition-all shadow-xs cursor-pointer flex items-center gap-1.5"
                >
                  <span>Завершить сопоставление</span>
                  <Check className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
        );
      })()}

      {/* Dynamic Pop-up Modal to view details about specific selected commercial bank */}
      {/* Dynamic Pop-up Modal to view details about specific selected commercial bank */}
      {selectedBankIdForModal && currentSelectedBankObj && (
        <div className="fixed inset-0 bg-slate-950/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-in fade-in duration-200">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-[28px] max-w-lg w-full overflow-hidden shadow-xl relative animate-in fade-in zoom-in-95 duration-250">
            <button
              onClick={() => setSelectedBankIdForModal(null)}
              className="absolute top-4 right-4 text-slate-400 dark:text-slate-500 hover:text-slate-800 dark:hover:text-white transition-colors p-1 cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="p-6 space-y-5">
              <div className="flex items-center gap-4 border-b border-slate-150 dark:border-slate-800 pb-4">
                {renderBankLogo(currentSelectedBankObj.id, currentSelectedBankObj.nameRu)}
                <div>
                  <h3 className="text-sm font-bold text-slate-900 dark:text-white">{currentSelectedBankObj.nameRu}</h3>
                  <a
                    href={currentSelectedBankObj.website}
                    target="_blank"
                    rel="noopener noreferrer"
                    onClick={(e) => handleSafeLinkClick(e, currentSelectedBankObj.website, currentSelectedBankObj.nameRu)}
                    className="text-xs text-blue-600 dark:text-blue-400 hover:text-blue-700 dark:hover:text-blue-300 font-bold hover:underline flex items-center gap-0.5 mt-0.5 cursor-pointer"
                  >
                    <span>{currentSelectedBankObj.website}</span>
                    <ExternalLink className="w-3 h-3" />
                  </a>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4 text-xs font-sans">
                <div className="bg-slate-50 dark:bg-slate-950 p-3 rounded-xl border border-slate-200 dark:border-slate-800">
                  <span className="text-[10px] text-slate-450 dark:text-slate-400 uppercase block font-bold tracking-wide">Рейтинг клиентов</span>
                  <strong className="text-amber-500 mt-1 block font-extrabold">★ {currentSelectedBankObj.rating.toFixed(1)} / 5.0</strong>
                </div>
                <div className="bg-slate-50 dark:bg-slate-950 p-3 rounded-xl border border-slate-200 dark:border-slate-800">
                  <span className="text-[10px] text-slate-450 dark:text-slate-400 uppercase block font-bold tracking-wide">Мин. ставка кредита</span>
                  <strong className="text-emerald-600 dark:text-emerald-400 mt-1 block font-extrabold font-mono">от {currentSelectedBankObj.creditMinRateKgs}% (сом)</strong>
                </div>
                <div className="bg-slate-50 dark:bg-slate-950 p-3 rounded-xl border border-slate-200 dark:border-slate-800">
                  <span className="text-[10px] text-slate-450 dark:text-slate-400 uppercase block font-bold tracking-wide">Макс. вклад сомы</span>
                  <strong className="text-blue-600 dark:text-blue-400 mt-1 block font-extrabold font-mono">до {currentSelectedBankObj.depositMaxRateKgs}% годовых</strong>
                </div>
                <div className="bg-slate-50 dark:bg-slate-950 p-3 rounded-xl border border-slate-200 dark:border-slate-800">
                  <span className="text-[10px] text-slate-450 dark:text-slate-400 uppercase block font-bold tracking-wide">Телефон доверия</span>
                  <strong className="text-slate-800 dark:text-slate-200 mt-1 block font-extrabold">{currentSelectedBankObj.phone}</strong>
                </div>
              </div>

              {/* Specific Bank Programs Deep Links */}
              <div className="border-t border-slate-150 dark:border-slate-800 pt-4 grid grid-cols-2 gap-3">
                {currentSelectedBankObj.creditUrl && (
                  <a
                    href={currentSelectedBankObj.creditUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    onClick={(e) => handleSafeLinkClick(e, currentSelectedBankObj.creditUrl!, currentSelectedBankObj.nameRu)}
                    className="flex items-center justify-center gap-1.5 py-2.5 px-3 bg-blue-50 dark:bg-blue-950/45 hover:bg-blue-100/70 dark:hover:bg-blue-900/40 text-blue-700 dark:text-blue-300 text-xs font-bold rounded-xl border border-blue-200/50 dark:border-blue-900/40 transition-all cursor-pointer text-center"
                  >
                    <Scale className="w-4 h-4 text-blue-500 dark:text-blue-400" />
                    <span>Тарифы кредитов ↗</span>
                  </a>
                )}
                {currentSelectedBankObj.depositUrl && (
                  <a
                    href={currentSelectedBankObj.depositUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    onClick={(e) => handleSafeLinkClick(e, currentSelectedBankObj.depositUrl!, currentSelectedBankObj.nameRu)}
                    className="flex items-center justify-center gap-1.5 py-2.5 px-3 bg-emerald-50 dark:bg-emerald-950/45 hover:bg-emerald-100/70 dark:hover:bg-emerald-900/40 text-emerald-700 dark:text-emerald-300 text-xs font-bold rounded-xl border border-emerald-200/50 dark:border-emerald-900/40 transition-all cursor-pointer text-center"
                  >
                    <Percent className="w-4 h-4 text-emerald-500" />
                    <span>Тарифы депозитов ↗</span>
                  </a>
                )}
              </div>

              {correspondingRealtimeRate && (
                <div className="bg-slate-50/50 dark:bg-slate-950/40 border border-slate-200 dark:border-slate-800 p-4 rounded-xl space-y-2 mt-2">
                  <h4 className="text-[10px] uppercase font-bold tracking-wider text-slate-500 dark:text-slate-400">Текущий курс обмена валют в сомах (KGS)</h4>
                  <div className="grid grid-cols-4 gap-2 text-center text-xs mt-2">
                    <div className="bg-white dark:bg-slate-900 p-1.5 rounded border border-slate-200 dark:border-slate-800 shadow-3xs">
                      <div className="text-slate-400 dark:text-slate-500 text-[9px] font-bold uppercase">USD Покупка</div>
                      <div className="font-extrabold text-emerald-600 dark:text-emerald-400 mt-0.5">{correspondingRealtimeRate.rates.USD.buy.toFixed(2)}</div>
                    </div>
                    <div className="bg-white dark:bg-slate-900 p-1.5 rounded border border-slate-200 dark:border-slate-800 shadow-3xs">
                      <div className="text-slate-400 dark:text-slate-500 text-[9px] font-bold uppercase">USD Продажа</div>
                      <div className="font-extrabold text-blue-600 dark:text-blue-400 mt-0.5">{correspondingRealtimeRate.rates.USD.sell.toFixed(2)}</div>
                    </div>
                    <div className="bg-white dark:bg-slate-900 p-1.5 rounded border border-slate-200 dark:border-slate-800 shadow-3xs">
                      <div className="text-slate-400 dark:text-slate-500 text-[9px] font-bold uppercase">EUR Покупка</div>
                      <div className="font-extrabold text-slate-800 dark:text-slate-250 mt-0.5">{correspondingRealtimeRate.rates.EUR.buy.toFixed(2)}</div>
                    </div>
                    <div className="bg-white dark:bg-slate-900 p-1.5 rounded border border-slate-200 dark:border-slate-800 shadow-3xs">
                      <div className="text-slate-400 dark:text-slate-500 text-[9px] font-bold uppercase">EUR Продажа</div>
                      <div className="font-extrabold text-slate-800 dark:text-slate-250 mt-0.5">{correspondingRealtimeRate.rates.EUR.sell.toFixed(2)}</div>
                    </div>
                  </div>
                </div>
              )}

              <div className="space-y-1.5 text-xs text-slate-500 dark:text-slate-400 pt-1">
                <div className="flex items-start gap-1.5">
                  <MapPin className="w-4 h-4 text-slate-400 dark:text-slate-500 shrink-0 mt-0.5" />
                  <span className="font-semibold">Адрес центрального филиала: {currentSelectedBankObj.address}</span>
                </div>
                <div className="text-[10px] text-slate-400 dark:text-slate-500 leading-relaxed font-sans mt-2 italic font-medium">
                  *Условия кредитов и вкладов подвержены периодическим изменениям со стороны банка. Перед совершением крупных сделок связывайтесь по горячей линии банка.
                </div>
              </div>
            </div>

            <div className="p-4 bg-slate-50 dark:bg-slate-950 border-t border-slate-200 dark:border-slate-800 flex gap-3">
              <a
                href={currentSelectedBankObj.website}
                target="_blank"
                rel="noopener noreferrer"
                onClick={(e) => handleSafeLinkClick(e, currentSelectedBankObj.website, currentSelectedBankObj.nameRu)}
                className="flex-1 py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-bold text-center text-xs rounded-xl transition-all cursor-pointer"
              >
                Перейти на сайт банка КР
              </a>
              <button
                onClick={() => setSelectedBankIdForModal(null)}
                className="bg-white dark:bg-slate-800 hover:bg-slate-50 dark:hover:bg-slate-700 text-slate-650 dark:text-slate-200 font-bold text-xs px-4 rounded-xl border border-slate-200 dark:border-slate-700 transition-colors cursor-pointer"
              >
                Закрыть
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Safe Link Redirect & Security Context Modal */}
      {safeLinkModal.isOpen && (
        <div className="fixed inset-0 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4 z-55 animate-in fade-in duration-200">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-[28px] max-w-md w-full overflow-hidden shadow-2xl relative animate-in fade-in zoom-in-95 duration-250">
            <button
              onClick={() => setSafeLinkModal(prev => ({ ...prev, isOpen: false }))}
              className="absolute top-4 right-4 text-slate-400 dark:text-slate-500 hover:text-slate-800 dark:hover:text-white transition-colors p-1 cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="p-6 space-y-5">
              <div className="flex items-center gap-3 border-b border-slate-150 dark:border-slate-800 pb-4">
                <div className="w-10 h-10 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200/50 dark:border-emerald-900/40 flex items-center justify-center text-emerald-600 dark:text-emerald-400 shrink-0">
                  <Globe className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-sm font-extrabold text-slate-900 dark:text-white">Безопасный переход</h3>
                  <p className="text-[10px] text-slate-500 mt-0.5">Официальный сайт {safeLinkModal.bankName}</p>
                </div>
              </div>

              <div className="space-y-3.5 text-xs text-slate-600 dark:text-slate-350 leading-relaxed font-sans">
                <p>
                  Поскольку интерактивная песочница AI Studio работает в защищенном фрейме (iframe), прямая ссылка банковских сервисов (например, <strong>{safeLinkModal.bankName}</strong>) блокируется вашим веб-браузером по умолчанию из-за строгой политики безопасности банков (защита от скрытого встраивания/Frame Protection).
                </p>

                <div className="bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200/50 dark:border-emerald-900/40 p-3.5 rounded-xl space-y-2">
                  <div className="flex items-center gap-2 text-emerald-800 dark:text-emerald-300 font-bold text-[11px]">
                    <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping" />
                    <span>Ссылка скопирована в буфер обмена!</span>
                  </div>
                  <p className="text-[10px] text-emerald-600 dark:text-emerald-400 font-medium">
                    Просто откройте новую вкладку в браузере и вставьте ссылку с помощью нажатия <strong>Ctrl + V</strong> (или зажмите адресную строку и нажмите "Вставить").
                  </p>
                </div>

                <div className="space-y-1.5 pt-1">
                  <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block font-sans">Оригинальный URL:</span>
                  <div className="flex items-center gap-2 bg-slate-50 dark:bg-slate-950 px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-800 select-all font-mono text-[10px] text-blue-600 dark:text-blue-400 break-all">
                    <span>{safeLinkModal.url}</span>
                    <button
                      onClick={() => {
                        try {
                          if (navigator.clipboard && navigator.clipboard.writeText) {
                            navigator.clipboard.writeText(safeLinkModal.url);
                            showToast("📋 Ссылка скопирована вручную!");
                          }
                        } catch (err) {
                          showToast("❌ Не удалось получить доступ к буферу");
                        }
                      }}
                      className="ml-auto text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 p-1 cursor-pointer shrink-0"
                      title="Скопировать ссылку"
                    >
                      <Copy className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>

              <div className="border-t border-slate-150 dark:border-slate-800 pt-4 flex gap-3">
                <button
                  onClick={() => {
                    // Try to trigger direct window open as standard popup helper just in case browser allows it.
                    window.open(safeLinkModal.url, "_blank", "noopener,noreferrer");
                  }}
                  className="flex-1 py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-bold text-center text-xs rounded-xl transition-all cursor-pointer flex items-center justify-center gap-1.5"
                >
                  <ExternalLink className="w-3.5 h-3.5" />
                  <span>Открыть в новой вкладке</span>
                </button>
                
                <button
                  onClick={() => setSafeLinkModal(prev => ({ ...prev, isOpen: false }))}
                  className="bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-650 dark:text-slate-200 font-bold text-xs px-4 rounded-xl transition-colors cursor-pointer"
                >
                  Понятно
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Styled Footer */}
      <footer className="border-t border-slate-200 bg-slate-50 py-10 text-center text-xs text-slate-500 mt-12">
        <div className="max-w-2xl mx-auto px-4 space-y-1 font-semibold">
          <p className="text-slate-600">© 2026 Valuta.kg Dashboard & Интеллектуальный Мониторинг</p>
          <p className="text-[11px] text-slate-400 font-sans leading-relaxed">
            Построен на основе данных котировок коммерческих платежных организаций Кыргызстана, valuta.kg и ИИ Google Gemini 2.5.
          </p>
        </div>
      </footer>

      {/* Floating Toast Notification */}
      <AnimatePresence>
        {toast && toast.visible && (
          <motion.div
            initial={{ opacity: 0, y: 40, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.95 }}
            className="fixed bottom-6 right-6 z-50 max-w-sm bg-slate-900/95 text-slate-50 dark:bg-white dark:text-slate-900 px-4 py-3.5 rounded-2xl shadow-xl flex items-center gap-3 border border-slate-800 dark:border-slate-200 font-sans text-xs backdrop-blur-md"
            id="app-global-toast"
          >
            <div className="bg-emerald-500/20 text-emerald-500 p-1.5 rounded-lg shrink-0">
              <Check className="w-4 h-4" />
            </div>
            <p className="font-semibold leading-normal">{toast.message}</p>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
