export interface ExchangeRate {
  buy: number;
  sell: number;
  buyChange?: 'up' | 'down' | 'stable';
  sellChange?: 'up' | 'down' | 'stable';
}

export interface BankRates {
  bankId: string;
  bankName: string;
  bankNameRu: string;
  website: string;
  logoUrl?: string;
  rates: {
    USD: ExchangeRate;
    EUR: ExchangeRate;
    RUB: ExchangeRate;
    KZT: ExchangeRate;
  };
  lastUpdated: string;
  isCustomSeed?: boolean;
}

export interface CurrencyHistoryPoint {
  date: string; // e.g. "12:00", "Yesterday", "2 days ago"
  USD: number;
  EUR: number;
  RUB: number;
  KZT: number;
}

export interface BankDetails {
  id: string;
  name: string;
  nameRu: string;
  website: string;
  logoType: string; // Used to render unique beautiful visual icons
  phone: string;
  address: string;
  rating: number;
  creditMinRateKgs: number; // e.g. 14%
  creditMinRateUsd: number; // e.g. 8%
  depositMaxRateKgs: number; // e.g. 12%
  depositMaxRateUsd: number; // e.g. 4%
  creditUrl?: string;
  depositUrl?: string;
}

export interface Message {
  sender: 'user' | 'assistant';
  text: string;
  timestamp: string;
  groundingSources?: Array<{ title: string; uri: string }>;
}
